import { build } from 'esbuild';
import { readFile,writeFile,mkdir } from 'node:fs/promises';
import { resolve,dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const root=dirname(fileURLToPath(import.meta.url));
const out=resolve(process.argv[2]||resolve(root,'dist'));
await mkdir(out,{recursive:true});
const bundle=await build({entryPoints:[resolve(root,'src/app.js')],bundle:true,format:'iife',target:['chrome100','edge100'],platform:'browser',write:false,minify:true,legalComments:'inline',metafile:true});
const template=await readFile(resolve(root,'src/template.html'),'utf8'),css=await readFile(resolve(root,'src/style.css'),'utf8');
const js=bundle.outputFiles[0].text.replace(/<\/script/gi,'<\\/script');
const licenses=await readFile(resolve(root,'LICENSES.md'),'utf8');
const licenseComment='<!-- Bundled dependency notices\n'+licenses.replace(/-->/g,'-- >')+'\n-->\n';
const html=template.replace('/* INLINE_CSS */',()=>css).replace('/* INLINE_JS */',()=>js).replace('</head>',()=>licenseComment+'</head>');
if(/<script[^>]+src=|<link[^>]+href=|@import|url\(\s*https?:/i.test(html))throw new Error('外部執行資源不得出現在離線單檔');
const output=resolve(out,'moon-phases-3d-offline.html');
await writeFile(output,html);
await writeFile(resolve(root,'references/build-manifest.json'),JSON.stringify({format:'IIFE embedded HTML',runtimeNetworkResources:0,buildTime:new Date().toISOString(),bytes:Buffer.byteLength(html),dependencies:{'astronomy-engine':'2.1.19',three:'0.180.0'},sources:Object.keys(bundle.metafile.inputs)},null,2)+'\n');
console.log(JSON.stringify({output,bytes:Buffer.byteLength(html),externalRuntimeResources:0}));
