import { chromium } from '@playwright/test';
import assert from 'node:assert/strict';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath, pathToFileURL } from 'node:url';
import path from 'node:path';
import { createHash } from 'node:crypto';

const root=fileURLToPath(new URL('..',import.meta.url));
const htmlPath=path.resolve(process.argv[2]||process.env.MOON_HTML_PATH||path.join(root,'dist','moon-phases-3d-offline.html'));
const htmlSource=await readFile(htmlPath,'utf8');
const htmlSha256=createHash('sha256').update(htmlSource).digest('hex');
let directFileResult=null,documentMethod='file://';
const evidenceDir=path.join(root,'references');
const shots=path.join(root,'work','screenshots');
await mkdir(shots,{recursive:true});
const results=[],pageErrors=[],consoleErrors=[],warnings=[],httpRequests=[],downloads=[];
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-webgl','--enable-unsafe-swiftshader','--disable-gpu-sandbox','--disable-background-networking']});
const context=await browser.newContext({viewport:{width:1600,height:1000},deviceScaleFactor:1,acceptDownloads:true,offline:true});
await context.route(/^https?:/,route=>{httpRequests.push(route.request().url());return route.abort();});
let page=await context.newPage();
function instrumentPage(p){
 p.setDefaultTimeout(15000);
 p.on('pageerror',e=>pageErrors.push(e.message));
 p.on('console',m=>{if(m.type()==='error')consoleErrors.push(m.text());if(m.type()==='warning')warnings.push(m.text());});
 p.on('request',r=>{if(/^https?:/.test(r.url())&&!httpRequests.includes(r.url()))httpRequests.push(r.url());});
}
instrumentPage(page);
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const js=fn=>page.evaluate(fn);
const state=()=>js(()=>{const l=window.__moonLab,s=l.state;return {time:+s.date,tab:s.tab,lat:s.lat,lon:s.lon,tz:s.tz,playing:s.playing,direction:s.direction,params:{...s.params},delta:s.snapshot.deltaLon,angle:s.snapshot.terminatorAngle,alt:s.snapshot.moon.alt,model:l.model?{delta:l.model.deltaLon,beta:l.model.beta,angle:l.model.terminatorAngle,alt:l.model.moon.alt,k:l.model.illumination}:null};});
const range=async(id,value)=>{await page.locator('#'+id).evaluate((el,value)=>{el.value=value;el.dispatchEvent(new Event('input',{bubbles:true}));},String(value));};
const chooseTab=async tab=>{await page.locator(`[data-tab="${tab}"]`).click();await page.waitForFunction(tab=>window.__moonLab.state.tab===tab,tab);await delay(80);};
const capture=async(name)=>{const filename=path.join(shots,name+'.png');await page.screenshot({path:filename,fullPage:false});return path.relative(root,filename);};
async function check(name,fn){const t=performance.now();try{const details=await fn();results.push({name,status:'passed',durationMs:Math.round(performance.now()-t),details:details??null});console.log('PASS',name);}catch(e){results.push({name,status:'failed',durationMs:Math.round(performance.now()-t),error:e.stack||String(e)});console.error('FAIL',name,e.message);await capture('failure-'+results.length).catch(()=>{});}}
function near(a,b,t=1e-7,msg=''){assert.ok(Math.abs(a-b)<=t,`${msg}: ${a} ≠ ${b} tolerance${t}`);}
function angular(a,b){return ((a-b+540)%360)-180;}
async function visiblePixels(view){return page.evaluate(key=>{const v=window.__moonLab.views[key];v.render();const gl=v.renderer.getContext(),w=gl.drawingBufferWidth,h=gl.drawingBufferHeight,pixels=new Uint8Array(w*h*4);gl.readPixels(0,0,w,h,gl.RGBA,gl.UNSIGNED_BYTE,pixels);let min=255,max=0,bright=0;const colors=new Set();for(let i=0;i<pixels.length;i+=52){const a=pixels[i],b=pixels[i+1],c=pixels[i+2];min=Math.min(min,a,b,c);max=Math.max(max,a,b,c);if(Math.max(a,b,c)>70)bright++;colors.add((a>>3)*1024+(b>>3)*32+(c>>3));}return{width:w,height:h,min,max,bright,colors:colors.size,contextLost:gl.isContextLost()};},view);}

try{
 try{
  await page.goto(pathToFileURL(htmlPath).href,{waitUntil:'load',timeout:90000});
  directFileResult={attempted:true,status:'opened',url:pathToFileURL(htmlPath).href};
 }catch(error){
  directFileResult={attempted:true,status:'blocked',url:pathToFileURL(htmlPath).href,error:error.message};
  if(!error.message.includes('ERR_BLOCKED_BY_ADMINISTRATOR'))throw error;
  console.log('LIMITATION directfile enterprise policy: ERR_BLOCKED_BY_ADMINISTRATOR; testing identical inline document with setContent.');
  documentMethod='Playwright setContent of exact HTML bytes';
  await page.close();page=await context.newPage();instrumentPage(page);
  await page.setContent(htmlSource,{waitUntil:'load',timeout:90000});
 }
 await check('single HTML initializes with all HTTP(S) blocked and browser offline',async()=>{
  await page.waitForFunction(()=>window.__moonLab?.ready,{},{timeout:90000});
  assert.equal(await page.locator('#fatal').isVisible(),false,await page.locator('#fatal').textContent());
  assert.equal(await page.locator('h1').textContent(),'月相變化 3D 互動實驗室');
  assert.equal(await js(()=>Object.keys(window.__moonLab.views).length),7,'all7WebGL views initialize');
  assert.equal(httpRequests.length,0,'no external resource request');
  return {url:page.url(),method:documentMethod,views:await js(()=>Object.keys(window.__moonLab.views)),offline:true};
 });
 if(!await js(()=>!!window.__moonLab?.ready))throw new Error('Application did not initialize; cannot run dependent UI checks.');

 await check('all4tabs render genuinely nonblank WebGL scenes',async()=>{
  const stats={};
  for(const [tab,keys] of [['space',['ideal','real']],['phase',['phaseMoon']],['ground',['sky','groundMoon']],['sandbox',['sandbox','sandboxMoon']]]){
   await chooseTab(tab);
   assert.equal(await page.locator('#panel-'+tab).isVisible(),true);
   for(const key of keys){const s=await visiblePixels(key);stats[key]=s;assert.equal(s.contextLost,false,key+'context intact');assert.ok(s.width>100&&s.height>100,key+'large view');assert.ok(s.colors>12&&s.max>90&&s.bright>10,key+'rendered geometry '+JSON.stringify(s));}
   await capture(tab+'-desktop');
  }
  return stats;
 });

 await check('all5event buttons search exact geocentric phases and nextNew wraps to new cycle',async()=>{
  await chooseTab('phase');
  await js(()=>window.__moonLab.setDate(new Date('2026-06-20T12:00Z')));
  const observed=[];
  for(const [name,angle] of [['newMoon',0],['firstQuarter',90],['fullMoon',180],['lastQuarter',270],['nextNewMoon',0]]){
   const expected=await page.evaluate(key=>+window.__moonLab.state.cycle[key],name);
   await page.locator(`[data-event="${name}"]`).click();
   const s=await state();near(s.time,expected,1,name+'exact event');near(angular(s.delta,angle),0,0.0002,name+'angle');assert.equal(s.playing,false);observed.push({name,time:new Date(s.time).toISOString(),delta:s.delta});
  }
  const n=await js(()=>+window.__moonLab.state.cycle.newMoon);near(n,observed.at(-1)?Date.parse(observed.at(-1).time):0,1,'new cycle anchored atnextNew');
  return observed;
 });

 await check('play/pause, reverse, speed,1hour/1day steps, timeline and pause freeze',async()=>{
  let before=(await state()).time;
  for(const [id,hours] of [['next-hour',1],['back-hour',-1],['next-day',24],['back-day',-24]]){await page.locator('#'+id).click();const after=(await state()).time;near(after-before,hours*3600000,1,id);before=after;}
  await page.locator('#speed').selectOption('24');
  await page.locator('#play').click();await delay(400);assert.equal((await state()).playing,true);assert.ok((await state()).time>before);
  await page.locator('#play').click();const paused=(await state()).time;await delay(350);near((await state()).time,paused,0,'pause freezes state');
  await page.locator('#reverse').click();await delay(350);assert.ok((await state()).time<paused);assert.equal((await state()).direction,-1);await page.locator('#play').click();
  await range('timeline',5000);
  const midway=await js(()=>({date:+window.__moonLab.state.date,start:+window.__moonLab.state.cycle.newMoon,end:+window.__moonLab.state.cycle.nextNewMoon}));near(midway.date,(midway.start+midway.end)/2,1,'timeline midpoint');
  return {playAdvanced:true,pauseFrozen:true,reverseWorked:true,timelineDate:new Date(midway.date).toISOString()};
 });

 await check('datetime/timezone controls change display convention without changing global instant',async()=>{
  await page.locator('#timezone').selectOption('8');
  await page.locator('#datetime').fill('2026-02-24T20:27');await page.locator('#datetime').dispatchEvent('change');
  const a=await state();assert.equal(new Date(a.time).toISOString(),'2026-02-24T12:27:00.000Z');
  await page.locator('#timezone').selectOption('0');near((await state()).time,a.time,0);assert.equal(await page.locator('#datetime').inputValue(),'2026-02-24T12:27');
  await page.locator('#timezone').selectOption('9');near((await state()).time,a.time,0);assert.equal(await page.locator('#datetime').inputValue(),'2026-02-24T21:27');
  await page.locator('#timezone').selectOption('8');
  return {utc:new Date(a.time).toISOString(),timeZones:['UTC+8','UTC','UTC+9']};
 });

 await check('phase chart/month bars/table load actual epochs;25rows are interactive',async()=>{
  await chooseTab('phase');
  const curve=page.locator('#phase-chart'),cbox=await curve.boundingBox();const cycle=await js(()=>({new:+window.__moonLab.state.cycle.newMoon,next:+window.__moonLab.state.cycle.nextNewMoon}));
  await curve.click({position:{x:42+(cbox.width-56)*.6,y:80}});near((await state()).time,cycle.new+.6*(cycle.next-cycle.new),2,'phase plot time jump');
  const chart=page.locator('#month-chart'),box=await chart.boundingBox();const row=await js(()=>({date:+window.__moonLab.state.months[5].firstQuarter}));
  await chart.click({position:{x:37+(box.width-45)*(5.5/25),y:90}});near((await state()).time,row.date,1,'monthly bar loads quarter');
  await page.locator('#months-toggle').click();assert.equal(await page.locator('#month-table tr').count(),25);
  const expected=await js(()=>+window.__moonLab.state.months[2].firstQuarter);await page.locator('[data-month-index="2"]').click();near((await state()).time,expected,1,'table loads quarter');
  await page.locator('#months-toggle').click();
  return {monthCount:25,curveClick:true,barClick:true,tableClick:true};
 });

 await check('e/perigee/clock lab controls produce numerical changes and real cases are searchable/replayable',async()=>{
  await chooseTab('phase');
  await range('lab-e',0);const circle=await page.locator('#lab-results').textContent();
  await range('lab-e',.1);const ellipse=await page.locator('#lab-results').textContent();assert.notEqual(circle,ellipse);
  await range('lab-peri',180);const rotated=await page.locator('#lab-results').textContent();assert.notEqual(ellipse,rotated);
  await range('lab-clock',0);const clock0=await page.locator('#lab-results').textContent();await range('lab-clock',23.9);const clock24=await page.locator('#lab-results').textContent();assert.notEqual(clock0,clock24);assert.ok(clock0.includes('初八')&&clock24.includes('初九'));
  await page.locator('#find-examples').click();await page.waitForFunction(()=>document.querySelectorAll('[data-example]').length>=3);
  const count=await page.locator('[data-example]').count();await page.locator('[data-example]').last().click();near(angular((await state()).delta,90),0,0.0002,'searched actual example');
  return {circleDiffersFromEllipse:true,perigeeChangesQuarter:true,clockChangesCivilDay:true,actualCaseKinds:count};
 });

 await check('space drag/zoom, synced comparison cameras, presets, overlays, scaling and visual amplification',async()=>{
  await chooseTab('space');await page.locator('#view-mode').selectOption('compare');
  const before=await js(()=>window.__moonLab.views.ideal.camera.position.toArray());
  const box=await page.locator('#space-ideal').boundingBox();await page.mouse.move(box.x+box.width*.5,box.y+box.height*.5);await page.mouse.down();await page.mouse.move(box.x+box.width*.7,box.y+box.height*.63,{steps:8});await page.mouse.up();
  const after=await js(()=>({ideal:window.__moonLab.views.ideal.camera.position.toArray(),real:window.__moonLab.views.real.camera.position.toArray()}));
  assert.ok(Math.hypot(...after.ideal.map((x,i)=>x-before[i]))>.5,'drag changes3Dcamera');after.ideal.forEach((x,i)=>near(x,after.real[i],1e-9,'camera sync'));
  const beforeDistance=Math.hypot(...after.ideal);await page.mouse.wheel(0,-300);await delay(100);const afterDistance=await js(()=>window.__moonLab.views.ideal.camera.position.length());assert.ok(afterDistance<beforeDistance,'wheel zoom');
  for(const preset of ['top','side','free'])await page.locator(`[data-view="${preset}"]`).click();
  const sizes=[];for(const mode of ['real','ideal','overlay','compare']){await page.locator('#view-mode').selectOption(mode);await delay(100);sizes.push({mode,ideal:await page.locator('#space-ideal').isVisible(),real:await page.locator('#space-real').isVisible()});}
  assert.equal(sizes[0].ideal,false);assert.equal(sizes[0].real,true);assert.equal(sizes[1].ideal,true);assert.equal(sizes[1].real,false);
  await page.locator('#view-mode').selectOption('overlay');assert.equal(await js(()=>window.__moonLab.views.real.overlayMoon.visible),true);
  await page.locator('#view-mode').selectOption('compare');await page.locator('#scale-mode').selectOption('distance');const small=await js(()=>window.__moonLab.views.real.earth.scale.x);await page.locator('#scale-mode').selectOption('teaching');const big=await js(()=>window.__moonLab.views.real.earth.scale.x);assert.ok(big>small);
  const beta=(await state()).delta;await range('amplify',4);near((await state()).delta,beta,1e-10,'visual amplification preserves science');assert.ok((await page.locator('#scale-notice').textContent()).includes('4×'));await range('amplify',1);
  await page.locator('#show-mean').uncheck();assert.equal(await js(()=>window.__moonLab.views.real.options.showMean),false);await page.locator('#show-mean').check();await page.locator('#show-trail').uncheck();assert.equal(await js(()=>window.__moonLab.views.real.options.showTrail),false);await page.locator('#show-trail').check();
  return {dragDistance:Math.hypot(...after.ideal.map((x,i)=>x-before[i])),zoomDistances:[beforeDistance,afterDistance],modeVisibility:sizes,bodyScales:{small,big}};
 });

 await check('ground coordinates, horizon-hidden state, follow/manual sky, reference toggles and horizon lock',async()=>{
  await chooseTab('ground');await js(()=>window.__moonLab.setDate(new Date('2026-01-26T04:47:56.246Z')));
  for(const [selector,lat] of [['[data-location="0,120.67"]',0],['[data-location="45,120.67"]',45],['[data-location="-35,120.67"]',-35],['[data-location="24.15,120.67"]',24.15]]){await page.locator(selector).click();near((await state()).lat,lat,1e-8);}
  await page.locator('#latitude').fill('-22.50');await page.locator('#latitude').dispatchEvent('change');await page.locator('#longitude').fill('42.00');await page.locator('#longitude').dispatchEvent('change');near((await state()).lat,-22.5,1e-8);near((await state()).lon,42,1e-8);
  await js(()=>{window.__moonLab.setLocation(24.15,120.67);let date=new Date('2026-01-26T00:00Z');for(let h=0;h<24;h++){const d=new Date(+date+h*3600000);if(window.__moonLab.science.ephemeris(d,24.15,120.67).moon.alt<-10){window.__moonLab.setDate(d);break;}}});
  assert.ok((await page.locator('#visibility').textContent()).includes('地平線下'));assert.equal(await js(()=>window.__moonLab.views.sky.moon.visible),false,'hidden below horizon');
  await page.locator('#below').check();assert.equal(await js(()=>window.__moonLab.views.sky.moon.visible),true,'透視 below horizon');await page.locator('#below').uncheck();
  const skybox=await page.locator('#ground-sky').boundingBox();await page.mouse.move(skybox.x+skybox.width*.5,skybox.y+skybox.height*.5);await page.mouse.down();await page.mouse.move(skybox.x+skybox.width*.65,skybox.y+skybox.height*.6,{steps:6});await page.mouse.up();assert.equal(await page.locator('#follow').isChecked(),false);await page.locator('#follow').check();assert.equal(await js(()=>window.__moonLab.views.sky.follow),true);
  for(const id of ['sky-ecliptic','sky-equator','sky-great']){await page.locator('#'+id).uncheck();await page.locator('#'+id).check();}
  const up=await js(()=>window.__moonLab.views.sky.camera.up.toArray());assert.deepEqual(up,[0,1,0]);
  const fov=await js(()=>window.__moonLab.views.sky.camera.fov);await page.locator('#ground-sky').hover();await page.mouse.wheel(0,-200);await delay(60);assert.ok(await js(()=>window.__moonLab.views.sky.camera.fov)<fov);
  return {belowHorizonHandled:true,manualDisablesFollow:true,cameraUp:up};
 });

 await check('4ground experiments preserve physical geometry and case buttons reproduce requested conditions',async()=>{
  await chooseTab('ground');const cases=[];
  for(const [kind,count] of [['latitude',5],['time',5],['season',4],['hemisphere',2]]){
   await page.locator(`[data-experiment="${kind}"]`).click();assert.equal(await page.locator('[data-ground-case]').count(),count);
   const date=(await state()).time;await page.locator('[data-ground-case]').last().click();const after=await state();
   if(kind==='latitude'||kind==='hemisphere'){near(after.time,date,1);near(angular(after.delta,90),0,.0002);}
   if(kind==='latitude')near(after.lat,65,1e-8);if(kind==='hemisphere')near(after.lat,-35,1e-8);if(kind==='time')assert.ok(after.time>date);if(kind==='season')assert.equal(new Date(after.time).getUTCMonth(),9);
   cases.push({kind,count,date:new Date(after.time).toISOString(),lat:after.lat,angle:after.angle,alt:after.alt});
  }
  return cases;
 });

 await check('sandbox all5parameter sliders are live and never mutate true ephemeris; ideal/mean presets and quizzes work',async()=>{
  await chooseTab('sandbox');const baseline=await state(),record=[];
  for(const [key,value] of [['e',.09],['i',9],['node',270],['peri',89],['phase',180]]){
   const before=await js(()=>window.__moonLab.model.moonEcl.slice());await range('param-'+key,value);const s=await state();near(s.params[key],value,1e-8,key+'stored');near(s.delta,baseline.delta,1e-10,'true ephemeris protected');const after=await js(()=>window.__moonLab.model.moonEcl.slice());assert.ok(Math.hypot(...after.map((x,i)=>x-before[i]))>1e-7,key+'moves actual3Dorbit');record.push({key,value,modelDelta:s.model.delta});
  }
  await page.locator('#sandbox-ideal').click();near((await state()).params.e,0);near((await state()).params.i,0);await page.locator('#sandbox-mean').click();near((await state()).params.e,.0549);near((await state()).params.i,5.145);
  assert.equal(await page.locator('.quiz').count(),5);for(let i=0;i<5;i++){await page.locator(`[data-quiz="${i}"][data-choice="1"]`).click();assert.equal(await page.locator('#answer-'+i).isVisible(),true);}
  return record;
 });

 await check('one-click i=0° counterexample finds above-horizon tilted cases and reproduces3Dmoon',async()=>{
  await chooseTab('sandbox');await js(()=>{window.__moonLab.setLocation(24.15,120.67);window.__moonLab.setDate(new Date('2026-06-20T12:00Z'));});
  await page.locator('#counterexample').click();const count=await page.locator('[data-counter-case]').count();assert.ok(count>0,'actual search produced cases');
  let s=await state();near(s.params.i,0);near(s.params.e,0);near(s.model.beta,0,1e-12);assert.ok(s.model.alt>8);assert.ok(Math.abs(s.model.angle)>15);
  const first=s.time;await page.locator('[data-counter-case]').last().click();s=await state();near(s.params.i,0);assert.ok(s.model.alt>8);assert.ok(Number.isFinite(s.model.angle));
  return {count,firstDate:new Date(first).toISOString(),replayedDate:new Date(s.time).toISOString(),angle:s.model.angle,alt:s.model.alt};
 });

 await check('high-resolution PNG and data CSV are real browser downloads with valid file contents',async()=>{
  await chooseTab('ground');
  const pngWait=page.waitForEvent('download');await page.locator('#export-png').click();const png=await pngWait,pngPath=path.join(shots,'export.png');await png.saveAs(pngPath);const bytes=await readFile(pngPath);assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');assert.equal(bytes.readUInt32BE(16),3200);assert.equal(bytes.readUInt32BE(20),1800);assert.ok(bytes.length>50000);downloads.push({name:png.suggestedFilename(),bytes:bytes.length,width:3200,height:1800});
  const csvWait=page.waitForEvent('download');await page.locator('#export-csv').click();const csv=await csvWait,csvPath=path.join(shots,'export.csv');await csv.saveAs(csvPath);const text=await readFile(csvPath,'utf8'),lines=text.trim().split(/\r?\n/);assert.equal(lines.length,26);assert.ok(lines[0].includes('new_moon_UTC'));for(const line of lines.slice(1)){const columns=line.split(',');assert.equal(columns.length,5);assert.ok(Number.isFinite(Date.parse(columns[0])));assert.ok(+columns[2]>5&&+columns[2]<10);}downloads.push({name:csv.suggestedFilename(),rows:25,bytes:Buffer.byteLength(text)});
  return downloads;
 });

 await check('help, explanation-level toggle, reset and small-screen layout remain operable',async()=>{
  await page.locator('#help').click();assert.equal(await page.locator('#help-dialog').isVisible(),true);await page.locator('#close-help').click();
  await page.locator('#focus-toggle').click();assert.equal(await page.locator('.global-controls').isVisible(),false);assert.equal(await page.locator('.masthead').isVisible(),false);assert.equal(await page.locator('#focus-toggle').isVisible(),true);await page.locator('#focus-toggle').click();assert.equal(await page.locator('.global-controls').isVisible(),true);
  await page.locator('#level').click();assert.equal(await page.locator('body').evaluate(el=>el.classList.contains('basic')),true);await page.locator('#level').click();
  await page.locator('#reset').click();const s=await state();near(s.lat,24.15);near(s.lon,120.67);near(angular(s.delta,90),0,.0002);
  await page.setViewportSize({width:390,height:844});await chooseTab('space');
  const size=await js(()=>({viewport:innerWidth,document:document.documentElement.scrollWidth,body:document.body.scrollWidth}));assert.ok(size.document<=size.viewport+2,'no full-page horizontal overflow '+JSON.stringify(size));
  const pixels=await visiblePixels('ideal');assert.ok(pixels.width>200&&pixels.colors>12);await capture('space-mobile');
  await chooseTab('ground');await capture('ground-mobile');await page.setViewportSize({width:1600,height:1000});
  return {smallScreen:size,canvasPixels:pixels};
 });

 await check('no fatal JS/console errors and zero HTTP(S) requests throughout offline session',async()=>{
  assert.deepEqual(pageErrors,[],'pageerror');assert.deepEqual(consoleErrors,[],'console.error');assert.deepEqual(httpRequests,[],'external network dependencies');
  return {pageErrors:0,consoleErrors:0,networkRequests:0,warnings};
 });
} catch(e){results.push({name:'browser harness',status:'failed',error:e.stack||String(e)});}
finally{
 const report={generatedAtUtc:new Date().toISOString(),htmlPath,htmlSha256,directFileResult,documentMethod,browser:'Chromium '+browser.version(),platform:process.platform,rendering:'Headless Chromium with ANGLE SwiftShader; HTTP(S) aborted, browser offline; direct-file result reported separately',counts:{passed:results.filter(r=>r.status==='passed').length,failed:results.filter(r=>r.status==='failed').length},pageErrors,consoleErrors,warnings,httpRequests,downloads,results};
 await writeFile(path.join(evidenceDir,'browser-results.json'),JSON.stringify(report,null,2)+'\n');
 await browser.close();console.log(JSON.stringify(report.counts));
 if(report.counts.failed)process.exitCode=1;
}
