import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import * as A from 'astronomy-engine';
import * as S from '../src/science.js';

const DAY=86400000, DEG=Math.PI/180;
const reference=JSON.parse(readFileSync(new URL('../references/usno-phases.json',import.meta.url)));
const v=(x)=>Array.isArray(x)?x:[x.x,x.y,x.z];
const add=(a,b)=>a.map((x,i)=>x+b[i]);
const sub=(a,b)=>a.map((x,i)=>x-b[i]);
const mul=(a,s)=>a.map(x=>x*s);
const dot=(a,b)=>a.reduce((r,x,i)=>r+x*b[i],0);
const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const length=(a)=>Math.hypot(...a);
const unit=(a)=>mul(a,1/length(a));
const wrap=(x)=>((x%360)+360)%360;
const diff=(a,b)=>((a-b+540)%360)-180;
const near=(a,b,t=1e-8,msg='')=>assert.ok(Math.abs(a-b)<=t,`${msg}: ${a} ≠ ${b} (tolerance ${t})`);
const vectorNear=(a,b,t=1e-10,msg='vector')=>a.forEach((x,i)=>near(x,b[i],t,`${msg}[${i}]`));
const dates=['2026-01-26T04:47:56.246Z','2026-04-24T02:32:00Z','2026-07-21T11:05:00Z','2026-10-18T16:13:19.496Z'];
const eventKey={0:'newMoon',90:'firstQuarter',180:'fullMoon',270:'lastQuarter'};

// External truth: USNO API v4.0.1. This is not a second call to the same
// application's astronomy wrapper. UT minute rounding is included in tolerance.
test('independent USNO: 50 primary phase events across all12calendar months, ≤3 minutes',()=>{
 const rows=[];
 assert.equal(new Set(reference.events.map(r=>r.utc.slice(0,7))).size,12,'independent reference covers12distinct calendar months');
 for(const ref of reference.events){
  const expected=new Date(ref.utc);
  const cycle=S.lunation(new Date(+expected+DAY));
  const actual=cycle[eventKey[ref.angle]];
  assert.ok(actual instanceof Date && Number.isFinite(+actual),`${ref.phase} returns Date`);
  const errorMinutes=(actual-expected)/60000;
  rows.push({...ref,actualUtc:actual.toISOString(),errorMinutes});
  assert.ok(Math.abs(errorMinutes)<=reference.toleranceMinutes,`${ref.phase} ${ref.utc}: ${errorMinutes.toFixed(3)} minutes`);
  near(diff(S.ephemeris(actual,24.15,120.67).deltaLon,ref.angle),0,0.0002,'event longitude root');
 }
 const maxAbsoluteErrorMinutes=Math.max(...rows.map(x=>Math.abs(x.errorMinutes)));
 writeFileSync(new URL('../references/usno-application-comparison.json',import.meta.url),JSON.stringify({source:reference.url,timeScale:'UTC / USNO UT to published minute',count:rows.length,toleranceMinutes:reference.toleranceMinutes,maxAbsoluteErrorMinutes,rows},null,2)+'\n');
 console.log(`USNO50: maximum absolute error ${maxAbsoluteErrorMinutes.toFixed(6)} min`);
});

test('geocentric apparent longitude difference is distinct from great-circle elongation',()=>{
 for(const text of dates){
  const s=S.ephemeris(new Date(text),24.15,120.67);
  const lambdaM=Math.atan2(s.moonEcl[1],s.moonEcl[0])/DEG;
  const lambdaS=Math.atan2(s.sunEcl[1],s.sunEcl[0])/DEG;
  near(diff(s.deltaLon,wrap(lambdaM-lambdaS)),0,1e-7,'ECT longitude difference');
  const expected=Math.acos(Math.max(-1,Math.min(1,dot(unit(s.moonEqj),unit(s.sunEqj)))))/DEG;
  near(s.elongation,expected,1e-7,'great-circle angle');
 }
 const n=S.lunation(new Date('2026-01-26T12:00Z')).newMoon;
 const s=S.ephemeris(n,24.15,120.67);
 near(diff(s.deltaLon,0),0,0.0002);
 assert.ok(s.elongation>0.1,'new moon may have nonzero geocentric sky separation due to latitude');
});

test('coordinate frames EQJ→ECT use date rotation and preserve AU distances',()=>{
 for(const text of dates){
  const date=new Date(text),s=S.ephemeris(date,24.15,120.67);
  const rot=A.Rotation_EQJ_ECT(date);
  for(const body of ['moon','sun']){
   const raw=s[body+'Eqj'];
   const expected=v(A.RotateVector(rot,new A.Vector(...raw,date)));
   vectorNear(s[body+'Ecl'],expected,1e-12,body+' ECT');
   near(length(raw),length(s[body+'Ecl']),1e-12,body+' distance invariant');
  }
  assert.ok(s.moonDistanceKm>350000 && s.moonDistanceKm<410000);
  near(s.beta,Math.asin(s.moonEcl[2]/length(s.moonEcl))/DEG,1e-8,'ecliptic latitude');
 }
});

test('topocentric Moon view and lighting use common-epoch EQJ vectors and observer parallax',()=>{
 for(const text of dates){
  const date=new Date(text),s=S.ephemeris(date,24.15,120.67);
  const expectedU=unit(sub(s.moonEqj,s.observerEqj));
  const expectedLight=unit(sub(s.sunEqj,s.moonEqj));
  vectorNear(s.moon.uEqj,expectedU,1e-11,'topocentric line of sight');
  vectorNear(s.lightEqj,expectedLight,1e-11,'moon to sun');
  near(s.illumination,(1+dot(expectedLight,mul(expectedU,-1)))/2,1e-10,'phase angle formula');
  near(s.geoIllumination,(1+dot(expectedLight,mul(unit(s.moonEqj),-1)))/2,1e-10,'geocentric phase angle');
  assert.ok(length(sub(expectedU,unit(s.moonEqj)))>1e-5,'topocentric parallax must not be omitted');
 }
});

test('ENU axes and horizon azimuth: east90°, north0°, up+altitude; independent engine Horizon agreement',()=>{
 for(const text of dates){
  const date=new Date(text),lat=24.15,lon=120.67,s=S.ephemeris(date,lat,lon);
  for(const [key,body] of [['moon','Moon'],['sun','Sun']]){
   const enu=s[key].enu;
   near(length(enu),1,1e-10,'ENU unit');
   near(diff(s[key].az,wrap(Math.atan2(enu[0],enu[1])/DEG)),0,1e-8,key+' azimuth');
   near(s[key].alt,Math.asin(enu[2])/DEG,1e-8,key+' altitude');
   const eq=A.Equator(body,date,new A.Observer(lat,lon,0),true,false);
   const hor=A.Horizon(date,new A.Observer(lat,lon,0),eq.ra,eq.dec);
   near(diff(s[key].az,hor.azimuth),0,0.02,key+' engine azimuth');
   near(s[key].alt,hor.altitude,0.02,key+' engine altitude');
  }
 }
});

test('horizon-locked screen is orthonormal, upright and right-handed with correct projected illumination angle',()=>{
 for(const text of dates){
  const s=S.ephemeris(new Date(text),24.15,120.67),u=s.moon.uEqj;
  const r=s.rightEqj,up=s.screenUpEqj,z=s.upEqj;
  for(const a of [u,r,up,z])near(length(a),1,1e-10);
  near(dot(r,u),0,1e-10);near(dot(up,u),0,1e-10);near(dot(r,up),0,1e-10);
  vectorNear(r,unit(cross(u,z)),1e-10,'screen right=u×zenith');
  vectorNear(up,cross(r,u),1e-10,'screen up');
  assert.ok(dot(up,z)>0,'screen up points toward local zenith');
  const bright=Math.atan2(dot(s.lightEqj,r),dot(s.lightEqj,up))/DEG;
  if(s.angleStable)near(diff(s.brightAngle,bright),0,1e-7,'bright-side orientation');
  assert.ok(s.terminatorAngle>=-90 && s.terminatorAngle<90,'unoriented terminator has 180° equivalence');
  const lineDifference=((s.terminatorAngle-s.brightAngle)%180+180)%180;
  near(lineDifference,90,1e-7,'terminator perpendicular to illumination projection');
 }
});

test('one global geocentric first-quarter instant, different local horizons and position angles',()=>{
 const q=S.lunation(new Date('2026-04-25T00:00Z')).firstQuarter;
 const states=[[24.15,120.67],[0,120.67],[45,120.67],[-35,120.67]].map(([lat,lon])=>S.ephemeris(q,lat,lon));
 for(const s of states){near(diff(s.deltaLon,90),0,0.0002);assert.ok(s.illumination>0.48&&s.illumination<0.52);}
 assert.ok(Math.max(...states.map(s=>s.moon.alt))-Math.min(...states.map(s=>s.moon.alt))>20);
 assert.ok(Math.max(...states.map(s=>s.terminatorAngle))-Math.min(...states.map(s=>s.terminatorAngle))>10);
});

test('hidden Moon is represented below horizon and all ordinary output geometry remains finite',()=>{
 let hidden=0,visible=0;
 for(let h=0;h<24;h++){
  const s=S.ephemeris(new Date(Date.UTC(2026,0,26,h)),24.15,120.67);
  s.moon.alt<0?hidden++:visible++;
  for(const num of [s.moon.alt,s.moon.az,s.sun.alt,s.sun.az,s.illumination,s.brightAngle,s.terminatorAngle])assert.ok(Number.isFinite(num));
  assert.ok(s.illumination>=0 && s.illumination<=1);
 }
 assert.ok(hidden>0&&visible>0,'daily path must cross local horizon');
});

test('civil lunar-day count uses Taipei midnight, not floor(moon age)+1 or UTC date',()=>{
 const n=new Date('2000-02-05T13:04:01.520Z');
 const q=new Date('2000-02-12T23:22:01.741Z');
 assert.equal(S.lunarDay(q,n),9,'verified first-quarter example is civil day9');
 assert.equal(Math.floor((q-n)/DAY)+1,8,'age-derived floor would be wrong');
 assert.equal(S.lunarDay(new Date('2000-02-05T15:59:59Z'),n),1);
 assert.equal(S.lunarDay(new Date('2000-02-05T16:00:00Z'),n),2);
 assert.equal(S.lunarDay(new Date('2000-02-05T16:00:00Z'),n,0),1,'UTC day boundary differs');
 const day10=S.lunation(new Date('2002-01-22T02:00Z'));
 assert.equal(S.lunarDay(day10.firstQuarter,day10.newMoon),10,'actual search-derived day10 case');
});

test('Earth rotates eastward by sidereal rate; Sun and Moon both advance prograde from ecliptic north',()=>{
 const date=new Date('2026-06-01T00:00Z');
 const a=S.ephemeris(date,0,0),h=S.ephemeris(new Date(+date+3600000),0,0),b=S.ephemeris(new Date(+date+DAY),0,0);
 const spin=wrap(h.siderealDeg-a.siderealDeg);
 near(spin,360/23.9344696,0.002,'sidereal hour');
 const longitude=(p)=>Math.atan2(p[1],p[0])/DEG;
 const moonAdvance=wrap(longitude(b.moonEcl)-longitude(a.moonEcl));
 const sunAdvance=wrap(longitude(b.sunEcl)-longitude(a.sunEcl));
 assert.ok(moonAdvance>11&&moonAdvance<16,'Moon is prograde13°/day');
 assert.ok(sunAdvance>0.9&&sunAdvance<1.1,'solar direction must change about1°/day');
});

test('horizon right/left cardinal conventions and exact zenith/degenerate light have safe explicit states',()=>{
 const cases=[{u:[1,0,0],right:[0,-1,0],name:'east→south right'}, {u:[0,1,0],right:[1,0,0],name:'north→east right'}, {u:[-1,0,0],right:[0,1,0],name:'west→north right'}, {u:[0,-1,0],right:[-1,0,0],name:'south→west right'}];
 for(const c of cases){
  const o=S.horizonOrientation(c.u,[0.3,0.4,0.8]);
  vectorNear(o.right,c.right,1e-12,c.name);
  near(dot(o.screenUp,[0,0,1]),1,1e-12,'horizon-locked up');
 }
 for(const [u,light] of [[[0,0,1],[1,0,0]],[[1e-12,0,1],[0,1,0]],[[1,0,0],[1,0,0]],[[1,0,0],[-1,0,0]]]){
  const o=S.horizonOrientation(u,light);
  assert.equal(o.angleStable,false);
  assert.equal(o.brightAngle,null);
  assert.equal(o.terminatorAngle,null);
  for(const a of [o.right,o.screenUp,o.screenLight])assert.ok(a.every(Number.isFinite),'safe finite rendering basis');
  near(length(o.right),1,1e-10);
  near(length(o.screenUp),1,1e-10);
 }
});

test('ideal coplanar circular model: shared exact new moon, 90° in 7.38d, and moving Sun',()=>{
 const anchor=S.lunation(new Date('2026-01-26T12:00Z')).newMoon;
 const first=S.idealState(anchor,anchor);
 const q=S.idealState(new Date(+anchor+S.SYNODIC*DAY/4),anchor);
 near(diff(first.deltaLon,0),0,1e-9);
 near(q.deltaLon,90,1e-6,'Date millisecond quantization');
 near(q.beta,0,1e-12);
 near(q.radius,1,1e-12);
 near(S.SYNODIC/4,7.38265,0.0001);
 const after=S.idealState(new Date(+anchor+S.SIDEREAL*DAY),anchor);
 near(wrap(after.sunLon-first.sunLon),360*S.SIDEREAL/S.YEAR,1e-6);
 assert.ok(wrap(after.sunLon-first.sunLon)>26,'Sun advances during lunar sidereal orbit');
 const comparison=S.sandboxQuarterInterval({e:0,i:0,node:123,peri:77},245);
 near(comparison.days,S.SYNODIC/4,1e-8);
 near(diff(S.keplerState(0,comparison.params).deltaLon,0),0,1e-8);
 near(S.keplerState(comparison.days,comparison.params).deltaLon,90,1e-8);
});

test('Kepler equation, orbital plane and equal-area velocity are correct throughout e=0…0.1 sandbox range',()=>{
 for(const e of [0,0.0549,0.1]){
  const p={e,i:5.145,node:123,peri:47,phase:11};
  let firstArea;
  for(let j=0;j<=80;j++){
   const days=S.SIDEREAL*j/80,state=S.keplerState(days,p);
   near(diff((state.E-e*Math.sin(state.E))/DEG,state.meanAnomaly),0,1e-10,'Kepler M=E−e sinE');
   near(state.radius,1-e*Math.cos(state.E),1e-12,'orbital radius');
   near(length(state.position),state.radius,1e-12,'3D radius');
   const angularMomentum=cross(state.position,state.velocity);
   const area=length(angularMomentum)/2;
   if(firstArea===undefined)firstArea=area;
   near(area,firstArea,1e-12,'constant swept area per time');
   near(state.arealRate,area,1e-12,'reported areal rate');
   near(Math.acos(angularMomentum[2]/length(angularMomentum))/DEG,p.i,1e-10,'orbit inclination');
  }
  const a=S.keplerState(0,{...p,phase:0}),b=S.keplerState(S.SIDEREAL/2,{...p,phase:0});
  near(a.radius,1-e,1e-12,'perigee radius');
  near(b.radius,1+e,1e-12,'apogee radius');
  near(a.angularSpeed/b.angularSpeed,((1+e)/(1-e))**2,1e-10,'perigee moves faster');
 }
});

test('same new-moon alignment with changed eccentricity/perigee produces different searched quarter times',()=>{
 const rows=[0,90,180,270].map(peri=>S.sandboxQuarterInterval({e:0.1,i:0,node:0,peri},0));
 for(const row of rows){
  near(diff(S.keplerState(0,row.params).deltaLon,0),0,1e-8,'shared new-moon geometry');
  near(S.keplerState(row.days,row.params).deltaLon,90,1e-8,'searched quarter condition');
  assert.ok(row.days>5 && row.days<10);
 }
 assert.ok(Math.max(...rows.map(r=>r.days))-Math.min(...rows.map(r=>r.days))>1,'perigee orientation changes quarter interval by a measurable amount');
 const circle=S.sandboxQuarterInterval({e:0,i:0,node:0,peri:0},0);
 assert.ok(rows.some(row=>Math.abs(row.days-circle.days)>0.5),'elliptical effect is not a fixed7.38-day schedule');
});

test('zero orbital inclination still yields a tilted local terminator (causal counterexample)',()=>{
 const anchor=S.lunation(new Date('2026-04-25T00:00Z')).newMoon;
 const at=new Date(+anchor+S.SYNODIC*DAY/4);
 const cases=[[24.15,120.67],[45,120.67],[-35,120.67],[0,0]].map(([lat,lon])=>S.modelTopocentric(at,lat,lon,{e:0,i:0,node:0,peri:0,phase:0},anchor));
 for(const s of cases){near(s.beta,0,1e-12);near(s.deltaLon,90,1e-6,'Date millisecond quantization');}
 const tilted=cases.filter(s=>s.angleStable && Math.abs(s.terminatorAngle)>15);
 assert.ok(tilted.length>0,'tilt can be large even when i=0°');
 const visibleTilt=tilted.filter(s=>s.moon.alt>0);
 assert.ok(visibleTilt.length>0,'at least one counterexample is above its horizon');
});

test('phase curve unwraps across360° with no false vertical jump and25-month intervals contain real variation',()=>{
 const date=new Date('2026-07-21T12:00Z'),cycle=S.lunation(date);
 const points=S.samplePhaseCycle(cycle.newMoon,181);
 assert.equal(points.length,181);near(points[0].real,0,1e-10);near(points.at(-1).real,360,1e-10);
 for(let j=1;j<points.length;j++){
  assert.ok(points[j].real>=points[j-1].real,'monotone unwrapped longitude');
  assert.ok(points[j].real-points[j-1].real<5,'no360° wrap discontinuity');
 }
 const months=S.monthlyIntervals(date,25);
 assert.equal(months.length,25);
 assert.equal(+months[12].newMoon,+cycle.newMoon,'12 cycles before and after selected lunation');
 const values=months.map(r=>r.days);
 assert.ok(Math.max(...values)-Math.min(...values)>1);
 for(const row of months){
  near(row.days,(row.firstQuarter-row.newMoon)/DAY,1e-10);
  near(diff(S.ephemeris(row.newMoon).deltaLon,0),0,0.0002);
  near(S.ephemeris(row.firstQuarter).deltaLon,90,0.0002);
  assert.equal(row.lunarDay,S.lunarDay(row.firstQuarter,row.newMoon));
 }
});

test('hourly ephemeris trajectory is dated,3D and separate from labelled mean-element ellipse',()=>{
 const date=new Date('2026-07-21T12:00Z');
 const path=S.trajectory(date,1,1,1);
 assert.equal(path.length,49);
 for(let j=1;j<path.length;j++)assert.equal(path[j].date-path[j-1].date,3600000,'hourly sampling');
 for(const row of [path[0],path[24],path.at(-1)]){
  const eqj=v(A.GeoMoon(row.date));
  const expected=v(A.RotateVector(A.Rotation_EQJ_ECT(date),new A.Vector(...eqj,row.date)));
  vectorNear(row.position,expected,1e-12,'dated fixed-ECT reference frame');
 }
 assert.ok(path.some(p=>Math.abs(p.position[2])>1e-5),'real lunar ecliptic latitude');
 const mean=S.meanOrbit(date,180);
 assert.equal(mean.points.length,181);
 assert.ok(mean.label.includes('非精確'),'mean-element ellipse is explicitly labelled conceptual');
 near(mean.inclination,5.145,1e-10);
 vectorNear(mean.points[0],mean.points.at(-1),1e-12,'mean ellipse closed');
 assert.ok(length(sub(path[0].position,path.at(-1).position))>1e-5,'finite true trajectory is not forced closed');
});


test('sandbox snapshot preserves the topocentric Sun object and its phase timing uses anchor Sun longitude',()=>{
 const anchor=S.lunation(new Date('2026-11-18T00:00:00Z')).newMoon;
 const anchorSun=S.ephemeris(anchor,24.15,120.67).sunLon;
 const p={e:0.1,i:0,node:0,peri:30,phase:0};
 const searched=S.sandboxQuarterInterval(p,anchorSun);
 const date=new Date(+anchor+searched.days*DAY);
 const model=S.modelTopocentric(date,24.15,120.67,p,anchor);
 assert.equal(Array.isArray(model.sun),false,'Sun must remain a sky-body object, not raw Kepler direction array');
 assert.ok(Number.isFinite(model.sun.az)&&Number.isFinite(model.sun.alt));
 near(length(model.sun.enu),1,1e-10,'sandbox Sun ENU unit vector');
 const expected=S.observerGeometry(date,24.15,120.67,model.moonEqj,model.sunEqj);
 near(model.sun.az,expected.sun.az,1e-10,'sandbox Sun azimuth matches same-epoch vectors');
 near(model.sun.alt,expected.sun.alt,1e-10,'sandbox Sun altitude matches same-epoch vectors');
 near(model.deltaLon,90,1e-6,'displayed searched quarter and model share anchor Sun longitude');
 assert.ok(Math.abs(searched.days-S.sandboxQuarterInterval(p).days)>0.5,'wrong normalized Sun anchor would materially change this interval');
});
