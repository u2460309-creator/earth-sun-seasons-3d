import * as S from './science.js';
import { SpaceView } from './space.js';
import { MoonView, SkyView } from './ground.js';

const $=id=>document.getElementById(id);
const all=selector=>[...document.querySelectorAll(selector)];
// A fixed, reproducible opening example above the Taiwan horizon; “Now” uses the user's clock.
const initialDate=S.searchPhase(90,new Date('2026-11-09T00:00:00Z'));
const state={date:new Date(initialDate),lat:24.15,lon:120.67,tz:8,tab:'space',playing:false,direction:1,speed:6,params:{e:.0549,i:5.145,node:125,peri:318,phase:0},cycle:null,months:[],curve:[],snapshot:null};
const views={};
let noticeTimer,cycleKey='',orbitKey='',trail=[],mean=null,modelSnapshot=null,lastTime=performance.now(),lastUpdate=0;
let running=false,paintCount=0;
const fmt=(n,d=2)=>Number(n).toFixed(d);
const deg=(n,d=1)=>Number.isFinite(n)?`${fmt(n,d)}°`:'角度未定義';
const signed=(n,d=1)=>Number.isFinite(n)?`${n>=0?'+':''}${fmt(n,d)}°`:'不穩定／未定義';
const shifted=(date,days)=>new Date(+date+days*S.DAY);
function dateString(date,offset=state.tz,seconds=false){
  const iso=new Date(+date+offset*S.DAY/24).toISOString();
  return iso.slice(0,10)+' '+iso.slice(11,seconds?19:16);
}
function monthLabel(date){return dateString(date,8).slice(0,7);}
function zoneLabel(offset=state.tz){return `UTC${offset>=0?'+':''}${offset}`;}
function showNotice(message){$('notice').textContent=message;$('notice').classList.add('show');clearTimeout(noticeTimer);noticeTimer=setTimeout(()=>$('notice').classList.remove('show'),4500);}
function safe(handler){return event=>{try{handler(event);}catch(error){showNotice(error.message);console.error(error);}};}
function setPlaying(value,direction=state.direction){state.playing=value;state.direction=direction;$('play').textContent=value?'❚❚ 暫停':'▶ 播放';$('play').setAttribute('aria-pressed',String(value));$('reverse').classList.toggle('selected',value&&direction<0);}
function setDate(date,{pause=true}={}){
  date=new Date(date);
  if(!Number.isFinite(+date))throw new Error('請輸入有效日期與時間');
  if(date.getUTCFullYear()<1900||date.getUTCFullYear()>2100){setPlaying(false);showNotice('本教學系統日期範圍為 1900–2100 年');return;}
  if(pause)setPlaying(false);
  state.date=date;
  update();
}
function location(lat,lon){state.lat=S.clamp(+lat,-65,65);state.lon=S.clamp(+lon,-180,180);$('latitude').value=fmt(state.lat,2);$('longitude').value=fmt(state.lon,2);update();}
function phaseName(delta){const names=['朔','眉月','上弦附近','盈凸月','望附近','虧凸月','下弦附近','殘月'];return names[Math.round(S.wrap360(delta)/45)%8];}
function setTab(tab){
  state.tab=tab;all('[data-tab]').forEach(b=>{const on=b.dataset.tab===tab;b.classList.toggle('active',on);b.setAttribute('aria-current',on?'page':'false');});
  all('.panel').forEach(p=>p.classList.toggle('active',p.id===`panel-${tab}`));
  const contextTag=document.querySelector('.status-strip .tag');contextTag.className='tag '+(tab==='sandbox'?'model':'fact');contextTag.textContent=tab==='sandbox'?'假設性模型（共用時刻）':'精確星曆';
  update();requestAnimationFrame(()=>{Object.values(views).forEach(v=>v.resize());drawCharts();renderActive();});
}
function circlePath(){return Array.from({length:181},(_,i)=>[Math.cos(i/180*2*Math.PI)*S.LUNAR_A,Math.sin(i/180*2*Math.PI)*S.LUNAR_A,0]);}
const idealPath=circlePath();
function sandboxPath(params){return Array.from({length:181},(_,i)=>S.scale(S.keplerState(i/180*S.SIDEREAL,params).position,S.LUNAR_A));}
function commonSpaceOptions(){return {scale:$('scale-mode').value,amplify:+$('amplify').value,showGrid:true,showMean:$('show-mean').checked,showTrail:$('show-trail').checked};}
function updateCycles(){
  state.cycle=S.lunation(state.date);
  const key=String(+state.cycle.newMoon);
  if(key!==cycleKey){
    cycleKey=key;
    state.curve=S.samplePhaseCycle(state.cycle.newMoon);
    state.months=S.monthlyIntervals(state.date,25);
    fillMonthTable();
    updateLab();
  }
}
function update(){
  if(running)return;running=true;
  try{
    updateCycles();
    state.snapshot=S.ephemeris(state.date,state.lat,state.lon);
    const snap=state.snapshot,c=state.cycle,age=(state.date-c.newMoon)/S.DAY;
    $('datetime').value=dateString(state.date,state.tz).replace(' ','T');
    $('utc-time').textContent=`${dateString(state.date,0,true)} UTC`;
    $('timeline-start').textContent=dateString(c.newMoon).slice(5);
    $('timeline-end').textContent=dateString(c.nextNewMoon).slice(5);
    $('timeline').value=Math.round((state.date-c.newMoon)/(c.nextNewMoon-c.newMoon)*10000);
    $('phase-caption').textContent=`${phaseName(snap.deltaLon)} · 地心照明 ${fmt(snap.geoIllumination*100,2)}%`;
    all('[data-event]').forEach(b=>{const close=Math.abs(state.date-c[b.dataset.event])<60000;b.classList.toggle('active',close);b.title=`${dateString(c[b.dataset.event],state.tz,true)} ${zoneLabel()}`;});
    $('shared-facts').textContent=`${dateString(state.date)} ${zoneLabel()}　｜　${fmt(state.lat,2)}°N, ${fmt(state.lon,2)}°E　｜　月齡 ${fmt(age,3)} 天`;
    $('real-stage-facts').textContent=`β ${signed(snap.beta,2)} · ${Math.round(snap.moonDistanceKm).toLocaleString()} km`;
    $('beta-value').textContent=signed(snap.beta,3);
    $('delta-value').textContent=deg(snap.deltaLon,3);
    $('age-value').textContent=`${fmt(age,3)} 天`;
    $('lunar-day').textContent=S.lunarDayName(S.lunarDay(state.date,c.newMoon,8));
    $('elongation-value').textContent=deg(snap.elongation,3);
    $('illumination-value').textContent=`${fmt(snap.illumination*100,3)}%`;
    const interval=(c.firstQuarter-c.newMoon)/S.DAY;
    $('event-report').innerHTML=`本次朔：<b>${dateString(c.newMoon,8,true)}</b> 臺灣時間<br>本次上弦：<b>${dateString(c.firstQuarter,8,true)}</b> 臺灣時間<br>朔 → 上弦：<b>${fmt(interval,5)} 天／${fmt(interval*24,3)} 小時</b>；上弦落在 <b>${S.lunarDayName(S.lunarDay(c.firstQuarter,c.newMoon,8))}</b>`;
    updateGroundInfo();
    if(state.tab==='space')updateSpace();
    if(state.tab==='phase')views.phaseMoon?.update(snap);
    if(state.tab==='ground'){views.groundMoon?.update(snap);views.sky?.update(snap,skyOptions());}
    if(state.tab==='sandbox')updateSandbox();
    drawCharts();renderActive();paintCount++;
  }finally{running=false;}
}
function updateSpace(){
  const snap=state.snapshot,dayKey=Math.floor(+state.date/S.DAY);
  if(String(dayKey)!==orbitKey){orbitKey=String(dayKey);trail=S.trajectory(state.date).map(r=>r.position);mean=S.meanOrbit(state.date);}
  const ideal=S.idealState(state.date,state.cycle.newMoon);
  const opts=commonSpaceOptions();
  views.ideal?.update({...snap,...ideal},{...opts,position:ideal.moonEcl,trajectory:idealPath,showMean:false,overlayPosition:null,overlayPath:[]});
  const overlay=$('view-mode').value==='overlay';
  views.real?.update(snap,{...opts,trajectory:trail,meanOrbit:mean.points,inclination:mean.inclination,nodeDeg:mean.node,periDeg:mean.peri,eccentricity:.0549,overlayPosition:overlay?ideal.moonEcl:null,overlayPath:overlay?idealPath:[]});
}
function skyOptions(){return {follow:$('follow').checked,below:$('below').checked,ecliptic:$('sky-ecliptic').checked,equator:$('sky-equator').checked,greatCircle:$('sky-great').checked};}
function updateGroundInfo(){
  const snap=state.snapshot;
  let visibility=snap.visibility;
  if(snap.illumination<.025)visibility+='；近朔，月面極暗，幾何位置不代表可見';
  if(snap.moon.alt<0)visibility+=' · 特寫只供學習，地面不能直接看到此月面';
  $('visibility').textContent=visibility;
  $('angle-note').textContent=snap.angleStable?`分界線 ${signed(snap.terminatorAngle)}；亮側指向 ${signed(snap.brightAngle)}`:'角度此時不穩定／未定義（近天頂或光照投影退化）';
  const rows=[['月球：方位／幾何仰角',`${deg(snap.moon.az)} / ${signed(snap.moon.alt)}`,snap.moon.alt>=0?'地平線以上（仍須考慮天空亮度）':'地平線下，無法直接觀測'],['太陽：方位／幾何仰角',`${deg(snap.sun.az)} / ${signed(snap.sun.alt)}`,snap.sun.alt<0?'太陽在地平線下，照明方向仍存在':'白天，肉眼可見性受天空亮度影響'],['亮側指向角',snap.angleStable?signed(snap.brightAngle):'未定義','從鉛直向右順時針，指向太陽的投影'],['分界線相對鉛直傾角',snap.angleStable?signed(snap.terminatorAngle):'未定義','線方向取 [−90°, 90°)，與亮側角相差 90°']];
  $('ground-metrics').innerHTML=rows.map(([a,b,c])=>`<article><span class="metric-label">${a}</span><strong style="font-size:21px">${b}</strong><p>${c}</p></article>`).join('');
}
function updateSandbox(){
  const p=state.params,anchor=state.cycle.newMoon;
  modelSnapshot=S.modelTopocentric(state.date,state.lat,state.lon,p,anchor);
  const model=modelSnapshot,path=sandboxPath(p);
  views.sandbox?.update(model,{position:model.moonEcl,trajectory:path,meanOrbit:path,inclination:p.i,nodeDeg:p.node,periDeg:p.peri,eccentricity:p.e,showMean:true,showTrail:true,scale:$('scale-mode').value,amplify:1});
  views.sandboxMoon?.update(model);
  $('sandbox-time').textContent=`同一朔起點後 ${fmt(model.days,3)} 天`;
  const anchorSun=S.idealState(anchor,anchor).sunLon;
  const interval=S.sandboxQuarterInterval(p,anchorSun),st=S.keplerState(0,{...p,phase:0}),speedRatio=((1+p.e)/(1-p.e))**2;
  $('sandbox-results').innerHTML=`<div class="eyebrow">因果拆解 / 軌道平面 ≠ 地平月面</div><h3>軌道傾角 ${deg(p.i,3)}，分界線傾角 ${model.angleStable?signed(model.terminatorAngle):'未定義'}</h3><p>此假設模型的 Δλ = <b class="good">${deg(model.deltaLon,3)}</b>；照明 ${fmt(model.illumination*100,3)}%；地平仰角 ${signed(model.moon.alt)}。</p><p>從對齊的朔開始數值搜尋上弦：<b class="warn">${fmt(interval.days,5)} 天</b>。這個間隔由 e、i、Ω、ω 決定；初始相位滑桿只決定目前展示位置。</p><p>近／遠地點角速度比：<b>${fmt(speedRatio,4)}</b>。瞬時掃掠面積率為常數 <b>${fmt(st.arealRate,7)} a²／天</b>，符合克卜勒第二定律。</p><p>地平傾角另外受到地點（${fmt(state.lat,2)}°N, ${fmt(state.lon,2)}°E）與地球自轉決定。位置沿用 C 分頁的觀測站。</p>`;
}
function renderActive(){
  if(state.tab==='space'){views.ideal?.render();views.real?.render();}
  if(state.tab==='phase')views.phaseMoon?.render();
  if(state.tab==='ground'){views.sky?.render();views.groundMoon?.render();}
  if(state.tab==='sandbox'){views.sandbox?.render();views.sandboxMoon?.render();}
}
function chartContext(id){
  const canvas=$(id);if(!canvas.clientWidth)return null;
  const dpr=Math.min(devicePixelRatio||1,2),w=canvas.clientWidth,h=canvas.clientHeight;
  if(canvas.width!==Math.round(w*dpr)||canvas.height!==Math.round(h*dpr)){canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);}
  const g=canvas.getContext('2d');g.setTransform(dpr,0,0,dpr,0,0);g.clearRect(0,0,w,h);g.font='11px system-ui';g.fillStyle='#93a6bd';g.strokeStyle='#28384e';g.lineWidth=1;
  return {g,w,h};
}
function drawCharts(){
  if(state.tab!=='phase'||!state.curve.length)return;
  drawPhaseChart();drawMonthChart();
}
function drawPhaseChart(){
  const box=chartContext('phase-chart');if(!box)return;const {g,w,h}=box;
  const left=42,right=w-14,top=15,bottom=h-30,maxDays=(state.cycle.nextNewMoon-state.cycle.newMoon)/S.DAY;
  const x=d=>left+d/maxDays*(right-left),y=a=>bottom-a/380*(bottom-top);
  [0,90,180,270,360].forEach(a=>{g.strokeStyle=a===90?'#74683f':'#28384e';g.beginPath();g.moveTo(left,y(a));g.lineTo(right,y(a));g.stroke();g.fillStyle='#93a6bd';g.fillText(`${a}°`,5,y(a)+4);});
  for(let d=0;d<=maxDays;d+=5){g.fillStyle='#93a6bd';g.fillText(`${d}d`,x(d)-6,bottom+20);}
  for(const [key,color,dash] of [['real','#6edcde',[]],['ideal','#f3c76d',[6,5]]]){
    g.strokeStyle=color;g.lineWidth=2;g.setLineDash(dash);g.beginPath();state.curve.forEach((p,i)=>i?g.lineTo(x(p.days),y(p[key])):g.moveTo(x(p.days),y(p[key])));g.stroke();g.setLineDash([]);
  }
  const realDays=(state.cycle.firstQuarter-state.cycle.newMoon)/S.DAY,idealDays=S.SYNODIC/4;
  [[realDays,'#6edcde'],[idealDays,'#f3c76d']].forEach(([d,color])=>{g.fillStyle=color;g.beginPath();g.arc(x(d),y(90),4,0,Math.PI*2);g.fill();g.strokeStyle=color;g.setLineDash([3,4]);g.beginPath();g.moveTo(x(d),y(90)+6);g.lineTo(x(d),bottom);g.stroke();g.setLineDash([]);});
  const current=(state.date-state.cycle.newMoon)/S.DAY;g.strokeStyle='#dce8f1';g.lineWidth=1;g.beginPath();g.moveTo(x(current),top);g.lineTo(x(current),bottom);g.stroke();
  $('phase-chart-caption').textContent=`實際 ${fmt(realDays,4)} 天達 90°；理想 ${fmt(idealDays,4)} 天，差 ${fmt((realDays-idealDays)*24,2)} 小時。曲線使用連續展開角，點圖可跳轉。`;
}
function drawMonthChart(){
  const box=chartContext('month-chart');if(!box)return;const {g,w,h}=box,rows=state.months;
  const left=37,right=w-8,top=12,bottom=h-32,min=5.5,max=9,y=d=>bottom-(d-min)/(max-min)*(bottom-top),band=(right-left)/rows.length;
  [6,7,8,9].forEach(a=>{g.strokeStyle='#28384e';g.beginPath();g.moveTo(left,y(a));g.lineTo(right,y(a));g.stroke();g.fillStyle='#93a6bd';g.fillText(`${a}d`,4,y(a)+4);});
  const meanDays=rows.reduce((sum,r)=>sum+r.days,0)/rows.length;
  rows.forEach((r,i)=>{const active=Math.abs(r.newMoon-state.cycle.newMoon)<60000;g.fillStyle=active?'#f3c76d':'#68cbd3';g.globalAlpha=active?1:.6;g.fillRect(left+i*band+2,y(r.days),Math.max(2,band-4),bottom-y(r.days));g.globalAlpha=1;if(i%6===0){g.save();g.translate(left+i*band+band/2,bottom+16);g.textAlign='center';g.font='9px system-ui';g.fillStyle='#93a6bd';g.fillText(monthLabel(r.newMoon).slice(2),0,0);g.restore();}});
  g.strokeStyle='#ed998b';g.setLineDash([5,4]);g.beginPath();g.moveTo(left,y(meanDays));g.lineTo(right,y(meanDays));g.stroke();g.setLineDash([]);
  $('month-range').textContent=`${monthLabel(rows[0].newMoon)}—${monthLabel(rows.at(-1).newMoon)}：${fmt(Math.min(...rows.map(r=>r.days)),3)}–${fmt(Math.max(...rows.map(r=>r.days)),3)} 天。紅虛線為這 25 次平均 ${fmt(meanDays,4)} 天；點柱狀載入該次上弦。`;
}
function fillMonthTable(){
  $('month-table').innerHTML=state.months.map((r,i)=>`<tr><td>${dateString(r.newMoon,8,true)}</td><td>${dateString(r.firstQuarter,8,true)}</td><td>${fmt(r.days,5)}d／${fmt(r.hours,3)}h</td><td>${S.lunarDayName(r.lunarDay)}</td><td><button data-month-index="${i}" class="quiet compact">載入</button></td></tr>`).join('');
}
function updateLab(){
  const e=+$('lab-e').value,peri=+$('lab-peri').value,clock=+$('lab-clock').value;
  $('lab-e-value').textContent=fmt(e,4);$('lab-peri-value').textContent=deg(peri,0);
  const hour=Math.floor(clock),minute=Math.round((clock-hour)*60);$('lab-clock-value').textContent=`${String(hour).padStart(2,'0')}:${String(minute).padStart(2,'0')}`;
  const result=S.compareModels({e,i:0,node:0,peri});
  const civilIndex=Math.floor(clock/24+result.ideal.days)+1;
  $('lab-results').innerHTML=`<div><span>等速圓軌道朔 → 上弦</span><strong>${fmt(result.ideal.days,5)} 天</strong><span>${fmt(result.ideal.hours,3)} 小時</span></div><div><span>橢圓軌道朔 → 上弦</span><strong>${fmt(result.ellipse.days,5)} 天</strong><span>比圓軌道 ${result.differenceHours>=0?'晚':'早'} ${fmt(Math.abs(result.differenceHours),3)} 小時</span></div><div><span>理想同一月齡，只改朔鐘點</span><strong>${S.lunarDayName(civilIndex)}</strong><span>朔在 ${$('lab-clock-value').textContent}；月齡仍 ${fmt(result.ideal.days,5)} 天</span></div>`;
}
function actualExamples(){
  showNotice('正在本機搜尋前後 60 次朔望月的真實案例…');
  setTimeout(()=>{
    try{
      const examples=S.findLunarDayExamples(state.date,121);
      $('actual-examples').innerHTML=`<p>以下由星曆實際搜尋，不是虛構日期。搜尋期間 ${monthLabel(S.monthlyIntervals(state.date,121)[0].newMoon)}—${monthLabel(S.monthlyIntervals(state.date,121).at(-1).newMoon)}。</p><div class="result-options">${examples.map((r,i)=>`<button data-example="${i}"><b>${S.lunarDayName(r.lunarDay)}上弦</b><small>朔 ${dateString(r.newMoon,8,true)}<br>上弦 ${dateString(r.firstQuarter,8,true)}<br>月齡 ${fmt(r.days,5)} 天 · 臺灣時間</small></button>`).join('')}</div>`;
      all('[data-example]').forEach(b=>b.addEventListener('click',()=>setDate(examples[+b.dataset.example].firstQuarter)));
      showNotice(`找到 ${examples.length} 種實際上弦日序，可點選重現`);
    }catch(error){showNotice(error.message);console.error(error);}
  },20);
}
function experimentalRows(kind){
  const quarter=state.cycle.firstQuarter;
  if(kind==='latitude')return [-35,0,24.15,45,65].map(lat=>({date:quarter,lat,lon:state.lon,label:`${lat}° 緯度，同一上弦瞬間`}));
  if(kind==='hemisphere')return [35,-35].map(lat=>({date:quarter,lat,lon:state.lon,label:`${lat>0?'北':'南'}緯 35°，同一上弦瞬間`}));
  if(kind==='time')return [-6,-3,0,3,6].map(hours=>({date:shifted(quarter,hours/24),lat:state.lat,lon:state.lon,label:`同地點，上弦${hours>=0?'後':'前'} ${Math.abs(hours)} 小時`}));
  const year=state.date.getUTCFullYear();
  return [1,4,7,10].map(month=>{const date=S.searchPhase(90,new Date(Date.UTC(year,month-1,1)));return {date,lat:state.lat,lon:state.lon,label:`${year} 年 ${month} 月上弦（北半球季節）`};});
}
function groundExperiment(kind){
  setDate(state.cycle.firstQuarter);
  const rows=experimentalRows(kind),names={latitude:'鎖定同一上弦瞬間，改變緯度',time:'同一地點，讓地球自轉推進時間',season:'同一地點，對比四個季節的上弦',hemisphere:'同一上弦，北／南半球切換'};
  const element=$('ground-experiment');element.hidden=false;
  element.innerHTML=`<div class="eyebrow">一鍵實驗 / 點選數據可重現</div><h3>${names[kind]}</h3><p>${kind==='time'?'時間推進後相位也會連續變化，但幾小時內亮面比例變化較小，地平傾角則可明顯轉動。':kind==='season'?'每個月份使用各自搜尋到的精確上弦時刻；事件鐘點不同，地平差異同時包含季節與時角效應。':'各地的地心相位事件時刻完全相同，地表視差、仰角及地平傾角則不同。'}</p><div class="result-options">${rows.map((r,i)=>{const s=S.ephemeris(r.date,r.lat,r.lon);return `<button data-ground-case="${i}"><b>${r.label}</b><small>${dateString(r.date,8,true)} UTC+8<br>Δλ ${deg(s.deltaLon,3)} · 地心照明 ${fmt(s.geoIllumination*100,3)}%<br>月高 ${signed(s.moon.alt)} · 分界線 ${signed(s.terminatorAngle)}<br>${s.moon.alt<0?'地平線下，不能直接觀測':'地平線以上；仍須考慮天空亮度'}</small></button>`;}).join('')}</div>`;
  all('[data-ground-case]').forEach(b=>b.addEventListener('click',()=>{const row=rows[+b.dataset.groundCase];location(row.lat,row.lon);setDate(row.date);}));
  $('follow').checked=true;views.sky?.setFollow(true);update();
}
function syncParamControls(){for(const k of ['e','i','node','peri','phase']){$(`param-${k}`).value=state.params[k];$(`param-${k}-value`).textContent=k==='e'?fmt(state.params[k],4):deg(state.params[k],k==='i'?3:0);}}
function setParams(params){state.params={...state.params,...params};syncParamControls();update();}
function counterexample(){
  setParams({e:0,i:0,node:0,peri:0,phase:0});
  const anchor=state.cycle.newMoon,quarter=shifted(anchor,S.SYNODIC/4),rows=[];
  for(const lat of [-35,0,24.15,45])for(let hour=-4;hour<=4;hour+=2){const date=shifted(quarter,hour/24),s=S.modelTopocentric(date,lat,state.lon,state.params,anchor);if(s.moon.alt>8&&s.angleStable)rows.push({date,lat,lon:state.lon,s});}
  rows.sort((a,b)=>Math.abs(b.s.terminatorAngle)-Math.abs(a.s.terminatorAngle));
  const selected=rows.slice(0,5);
  const element=$('counterexample-results');element.hidden=false;
  element.innerHTML=`<div class="eyebrow">反例成立 / 軌道完全與黃道共面</div><h3>i = 0°，分界線仍有傾角</h3><p>以下由本機數值搜尋地平線以上的例子；月球傾角完全為零，改變地平參考系就能產生傾斜。點選任一案例載入 3D 月面。全為假設性圓軌道，並非真實星曆。</p><div class="result-options">${selected.map((r,i)=>`<button data-counter-case="${i}"><b>${r.lat}° 緯度 · 分界線 ${signed(r.s.terminatorAngle)}</b><small>${dateString(r.date,8,true)} UTC+8<br>Δλ ${deg(r.s.deltaLon,2)} · 月高 ${signed(r.s.moon.alt)} · 照明 ${fmt(r.s.illumination*100,2)}%</small></button>`).join('')}</div>`;
  all('[data-counter-case]').forEach(b=>b.addEventListener('click',()=>{const r=selected[+b.dataset.counterCase];location(r.lat,r.lon);setDate(r.date);}));
  if(selected.length){location(selected[0].lat,selected[0].lon);setDate(selected[0].date);}
  showNotice('已載入共面圓軌道的地平傾斜反例');
}
function initQuizzes(){
  const questions=[
    ['只改離心率 e，是否就能決定月面相對地平的旋轉？',['可以，e 越大就越斜','不能，還要看觀測幾何'],'不能由 e 單獨決定。e 影響軌道速度與相位到達時間；地平傾角由日月視線、當地鉛直與觀測時刻共同決定。請操作 e，再用 C 分頁換緯度比較。'],
    ['上弦一定在初八發生？',['是，每月固定','否，月齡與民用日序不同'],'不固定。B 分頁點「搜尋真實不同日序案例」，比較朔與上弦的精確臺灣時間；角速度變動與朔發生鐘點都會影響日序。'],
    ['上弦月只在傍晚才位於地平線上？',['只在傍晚','也可能白天或晚間在地平線上'],'上弦通常約中午升起、傍晚偏高、午夜附近落下，但會隨位置季節改變。C 分頁推進觀測時間可檢查幾何可見範圍；白天不一定容易用肉眼看到。'],
    ['把軌道傾角設為 0°，半月分界線一定直立？',['一定直立','仍可能傾斜或近水平'],'仍可能傾斜。點本頁「i = 0°」反例，觀察軌道平面不變，但觀測者的本地鉛直與日月大圓方向並不固定一致。'],
    ['一般月相是地球的影子遮住月球？',['是，地影每天移動','否，是觀察受光半球的方向不同'],'一般月相由日－月－觀測者幾何造成。地影只有在月食條件下才會遮暗月面；本模型未加入月食影錐。到 A、B 分頁從不同視角驗證受光向量。']
  ];
  $('quizzes').innerHTML=questions.map(([q,choices],i)=>`<article class="quiz"><div class="eyebrow">先預測，再操作 / ${i+1}</div><h3>${q}</h3><div class="choices">${choices.map((c,j)=>`<button data-quiz="${i}" data-choice="${j}">${c}</button>`).join('')}</div><p class="answer" id="answer-${i}" hidden></p></article>`).join('');
  all('[data-quiz]').forEach(b=>b.addEventListener('click',()=>{all(`[data-quiz="${b.dataset.quiz}"]`).forEach(other=>other.classList.toggle('selected',other===b));const answer=$(`answer-${b.dataset.quiz}`);answer.hidden=false;answer.textContent=`你的預測已記錄。${questions[+b.dataset.quiz][2]}`;}));
}
async function exportPNG(){
  renderActive();
  const canvas=document.createElement('canvas');canvas.width=3200;canvas.height=1800;const g=canvas.getContext('2d');g.fillStyle='#090f1b';g.fillRect(0,0,3200,1800);
  g.fillStyle='#e9edf5';g.font='bold 56px system-ui';g.fillText('月相變化 3D 互動實驗室',90,105);g.font='28px system-ui';g.fillStyle='#9babc1';g.fillText(`${dateString(state.date,8,true)} 臺灣時間｜${fmt(state.lat,2)}°N, ${fmt(state.lon,2)}°E｜${state.tab==='sandbox'?'假設性克卜勒模型':'Astronomy Engine 真實星曆'}`,90,162);
  const ids={space:$('view-mode').value==='ideal'?['space-ideal']:$('view-mode').value==='compare'?['space-ideal','space-real']:['space-real'],phase:['phase-moon','phase-chart','month-chart'],ground:['ground-sky','ground-moon'],sandbox:['sandbox-space','sandbox-moon']}[state.tab];
  const available=ids.map(id=>$(id)).filter(c=>c.width>0&&c.height>0);
  available.forEach((src,i)=>{let rect;if(available.length===1)rect=[80,230,3040,1400];else if(available.length===2)rect=[80+i*1540,300,1500,1150];else rect=i===0?[80,250,1440,1300]:[1600,270+(i-1)*650,1500,610];const [x,y,w,h]=rect;const ratio=Math.min(w/src.width,h/src.height),dw=src.width*ratio,dh=src.height*ratio;g.drawImage(src,x+(w-dw)/2,y+(h-dh)/2,dw,dh);});
  g.font='26px system-ui';g.fillStyle='#f3c76d';const s=state.tab==='sandbox'?modelSnapshot:state.snapshot;g.fillText(`Δλ ${deg(s.deltaLon,3)}｜照明 ${fmt(s.illumination*100,3)}%｜分界線 ${signed(s.terminatorAngle)}｜地平仰角 ${signed(s.moon.alt)}`,90,1650);g.fillStyle='#9babc1';g.font='23px system-ui';g.fillText('大小／距離及天空角直徑有教學放大。平均元素示意不是瞬時攝動軌道。',90,1710);
  const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));download(blob,`moon-lab-${state.tab}-${dateString(state.date,8).replace(/[: ]/g,'-')}.png`);showNotice('已匯出 3200 × 1800 PNG，含時間、位置與模型標記');
}
function download(blob,name){if(!blob)throw new Error('瀏覽器無法產生下載檔案');const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),2000);}
function exportCSV(){const rows=['new_moon_UTC,first_quarter_UTC,interval_days,interval_hours,Taipei_civil_lunar_day',...state.months.map(r=>[r.newMoon.toISOString(),r.firstQuarter.toISOString(),r.days,r.hours,r.lunarDay].join(','))];download(new Blob(['\uFEFF'+rows.join('\r\n')],{type:'text/csv;charset=utf-8'}),'moon-phase-intervals.csv');showNotice('已匯出前後 25 次朔至上弦的 CSV');}
function bind(){
  all('[data-tab]').forEach(b=>b.addEventListener('click',()=>setTab(b.dataset.tab)));
  $('datetime').addEventListener('change',safe(()=>{const value=$('datetime').value;if(value)setDate(new Date(new Date(value+'Z').getTime()-state.tz*S.DAY/24));}));
  $('timezone').addEventListener('change',()=>{state.tz=+$('timezone').value;update();});
  $('now').addEventListener('click',()=>setDate(new Date()));
  $('play').addEventListener('click',()=>setPlaying(!state.playing,1));$('reverse').addEventListener('click',()=>setPlaying(!(state.playing&&state.direction<0),-1));
  for(const [id,hours] of [['back-day',-24],['back-hour',-1],['next-hour',1],['next-day',24]])$(id).addEventListener('click',()=>setDate(shifted(state.date,hours/24)));
  $('speed').addEventListener('change',()=>state.speed=+$('speed').value);
  $('reset').addEventListener('click',()=>{location(24.15,120.67);setDate(initialDate);state.params={e:.0549,i:5.145,node:125,peri:318,phase:0};syncParamControls();Object.values(views).forEach(v=>{if(v.setView&&v!==views.sky)v.setView('free');});views.sky?.reset();update();showNotice('已回到 2026 年 11 月上弦與預設觀測站');});
  $('timeline').addEventListener('input',()=>{const c=state.cycle;setDate(new Date(+c.newMoon+($('timeline').value/10000)*(c.nextNewMoon-c.newMoon)));});
  all('[data-event]').forEach(b=>b.addEventListener('click',()=>setDate(state.cycle[b.dataset.event])));
  all('[data-view]').forEach(b=>b.addEventListener('click',()=>{views.ideal?.setView(b.dataset.view);views.real?.setView(b.dataset.view);all('[data-view]').forEach(other=>other.classList.toggle('selected',b===other));}));
  $('view-mode').addEventListener('change',()=>{$('space-pair').className='space-pair mode-'+$('view-mode').value;update();requestAnimationFrame(()=>{views.real?.resize();views.ideal?.resize();renderActive();});});
  ['scale-mode','show-mean','show-trail','amplify'].forEach(id=>$(id).addEventListener('input',()=>{$('amplify-label').textContent=$('amplify').value+'×';$('scale-notice').textContent=+$('amplify').value>1?`視覺放大傾角 ${$('amplify').value}×，不改計算；大小／距離未依同比例`:'大小／距離未依同比例';update();}));
  ['lab-e','lab-peri','lab-clock'].forEach(id=>$(id).addEventListener('input',updateLab));
  $('find-examples').addEventListener('click',actualExamples);
  $('months-toggle').addEventListener('click',()=>{$('month-table-wrap').hidden=!$('month-table-wrap').hidden;$('months-toggle').textContent=$('month-table-wrap').hidden?'展開精確時刻表':'收合精確時刻表';});
  $('month-table').addEventListener('click',event=>{const b=event.target.closest('[data-month-index]');if(b)setDate(state.months[+b.dataset.monthIndex].firstQuarter);});
  $('phase-chart').addEventListener('click',event=>{const rect=event.currentTarget.getBoundingClientRect(),frac=S.clamp((event.clientX-rect.left-42)/(rect.width-56),0,1);const c=state.cycle;setDate(new Date(+c.newMoon+frac*(c.nextNewMoon-c.newMoon)));});
  $('month-chart').addEventListener('click',event=>{const rect=event.currentTarget.getBoundingClientRect(),index=Math.floor((event.clientX-rect.left-37)/(rect.width-45)*state.months.length),row=state.months[S.clamp(index,0,state.months.length-1)];setDate(row.firstQuarter);});
  ['latitude','longitude'].forEach(id=>$(id).addEventListener('change',()=>location($('latitude').value,$('longitude').value)));
  all('[data-location]').forEach(b=>b.addEventListener('click',()=>location(...b.dataset.location.split(','))));
  ['follow','below','sky-ecliptic','sky-equator','sky-great'].forEach(id=>$(id).addEventListener('change',()=>{if(id==='follow')views.sky?.setFollow($('follow').checked);update();}));
  all('[data-experiment]').forEach(b=>b.addEventListener('click',safe(()=>groundExperiment(b.dataset.experiment))));
  for(const key of ['e','i','node','peri','phase'])$(`param-${key}`).addEventListener('input',()=>{state.params[key]=+$(`param-${key}`).value;syncParamControls();update();});
  $('sandbox-ideal').addEventListener('click',()=>setParams({e:0,i:0,node:0,peri:0,phase:0}));
  $('sandbox-mean').addEventListener('click',()=>setParams({e:.0549,i:5.145,node:125,peri:318,phase:0}));
  $('counterexample').addEventListener('click',safe(counterexample));
  $('level').addEventListener('click',()=>{const basic=document.body.classList.toggle('basic');$('level').textContent=basic?'顯示高中進階說明':'顯示高中基礎說明';});
  $('focus-toggle').addEventListener('click',()=>{const focused=document.body.classList.toggle('presentation');$('focus-toggle').textContent=focused?'顯示時間與參數控制':'收合控制／投影';requestAnimationFrame(()=>{Object.values(views).forEach(v=>v.resize());renderActive();drawCharts();});});
  $('export-png').addEventListener('click',()=>exportPNG().catch(error=>{showNotice(error.message);console.error(error);}));$('export-csv').addEventListener('click',exportCSV);
  $('help').addEventListener('click',()=>$('help-dialog').showModal());$('close-help').addEventListener('click',()=>$('help-dialog').close());
  window.addEventListener('resize',()=>{drawCharts();renderActive();});
  window.addEventListener('keydown',event=>{if(event.code==='Space'&&!['INPUT','SELECT','TEXTAREA','BUTTON'].includes(document.activeElement.tagName)){event.preventDefault();setPlaying(!state.playing);}});
}
function init(){
  bind();initQuizzes();syncParamControls();
  const constructors=[['ideal',SpaceView,'space-ideal',{kind:'ideal'}],['real',SpaceView,'space-real',{kind:'real'}],['phaseMoon',MoonView,'phase-moon'],['sky',SkyView,'ground-sky'],['groundMoon',MoonView,'ground-moon'],['sandbox',SpaceView,'sandbox-space',{kind:'sandbox'}],['sandboxMoon',MoonView,'sandbox-moon']];
  const errors=[];
  for(const [key,Type,id,options] of constructors){try{views[key]=new Type($(id),options);}catch(error){errors.push(`${id}: ${error.message}`);console.error(error);}}
  if(errors.length){$('fatal').hidden=false;$('fatal').textContent='部分 3D 視窗無法初始化。請在 Chrome／Edge 開啟，確認硬體加速與 WebGL 可用。計算與圖表仍可操作。細節：'+errors.join('；');}
  if(views.ideal&&views.real){views.ideal.onCameraChange=v=>views.real.setCameraFrom(v);views.real.onCameraChange=v=>views.ideal.setCameraFrom(v);}
  if(views.sky)views.sky.onManual=()=>{$('follow').checked=false;};
  update();
  window.__moonLab={state,science:S,views,setDate,setTab,setLocation:location,setParams,get model(){return modelSnapshot;},get paintCount(){return paintCount;},ready:true};
  function frame(now){
    lastTime=now;
    if(state.playing&&now-lastUpdate>80){
      const gap=(now-lastUpdate)/1000;lastUpdate=now;
      try{setDate(shifted(state.date,Math.min(gap,.25)*state.speed/24*state.direction),{pause:false});}catch(error){setPlaying(false);showNotice(error.message);console.error(error);}
    }else if(!state.playing)lastUpdate=now;
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
}
try{init();}catch(error){$('fatal').hidden=false;$('fatal').textContent='初始化失敗：'+error.message;console.error(error);}
