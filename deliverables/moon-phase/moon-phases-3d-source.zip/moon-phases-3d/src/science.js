/** Scientific kernel. Positions EQJ in AU, display orbit vectors ECT of date.
 * All public angular values are degrees unless explicitly named radians.
 * No network, no local timezone assumptions, no mutable ephemeris parameters.
 */
import * as Astronomy from 'astronomy-engine';

export const DEG = Math.PI / 180;
export const RAD = 180 / Math.PI;
export const DAY = 86400000;
export const AU_KM = Astronomy.KM_PER_AU;
export const SIDEREAL = 27.3217;
export const YEAR = 365.256;
export const SYNODIC = 1 / (1 / SIDEREAL - 1 / YEAR);
export const LUNAR_A = 384400 / AU_KM;
export const EARTH_RADIUS_KM = 6378.137;
export const DEFAULT_PARAMS = Object.freeze({ e: 0.0549, i: 5.145, node: 125.045, peri: 318.15, phase: 0, sunLon: 0 });
export const add = (a,b) => a.map((x,i)=>x+b[i]);
export const sub = (a,b) => a.map((x,i)=>x-b[i]);
export const scale = (a,k) => a.map(x=>x*k);
export const dot = (a,b) => a.reduce((s,x,i)=>s+x*b[i],0);
export const cross = (a,b) => [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
export const norm = a => Math.hypot(...a);
export const unit = (a,fallback=[1,0,0]) => norm(a)>1e-15?scale(a,1/norm(a)):fallback.slice();
export const clamp = (x,a=-1,b=1) => Math.max(a,Math.min(b,x));
export const wrap360 = x => ((x%360)+360)%360;
export const signed180 = x => wrap360(x+180)-180;
export const lineAngle = x => ((x+90)%180+180)%180-90;
export const vectorArray = v => [v.x,v.y,v.z];
const asDate = d => d instanceof Date?new Date(d.getTime()):new Date(d);
const shifted = (d,days) => new Date(+asDate(d)+days*DAY);
const av = (a,t) => new Astronomy.Vector(a[0],a[1],a[2],Astronomy.MakeTime(t));
export function rotate(rotation,a,date){return vectorArray(Astronomy.RotateVector(rotation,av(a,date)));}
export function eqjToEct(a,date){return rotate(Astronomy.Rotation_EQJ_ECT(date),a,date);}
export function ectToEqj(a,date){return rotate(Astronomy.Rotation_ECT_EQJ(date),a,date);}

/** Horizon-locked screen basis for any right-handed coordinate frame.
 * u points from observer toward Moon; light points Moon toward Sun; zenith up.
 */
export function horizonOrientation(uInput,lightInput,zenith=[0,0,1],east=[1,0,0]){
  const u=unit(uInput),light=unit(lightInput),up=unit(zenith);
  const horizontal=norm(cross(u,up));
  const right=horizontal>1e-8?unit(cross(u,up)):unit(sub(east,scale(u,dot(east,u))),[0,1,0]);
  const screenUp=unit(cross(right,u));
  const projected=sub(light,scale(u,dot(light,u)));
  const angleStable=horizontal>1e-5 && norm(projected)>1e-6;
  const brightAngle=angleStable?Math.atan2(dot(projected,right),dot(projected,screenUp))*RAD:null;
  return {right,screenUp,projected,angleStable,brightAngle,terminatorAngle:angleStable?lineAngle(brightAngle+90):null,
    screenLight:[dot(light,right),dot(light,screenUp),-dot(light,u)]};
}

/** Geometry common to real and hypothetical trajectories, EQJ in AU. */
export function observerGeometry(date,lat,lon,moonEqj,sunEqj){
  date=asDate(date);
  lat=clamp(Number(lat),-90,90); lon=Number(lon);
  const observer=new Astronomy.Observer(lat,lon,0);
  const observerEqj=vectorArray(Astronomy.ObserverVector(date,observer,false));
  const eqjHor=Astronomy.Rotation_EQJ_HOR(date,observer);
  const horEqj=Astronomy.InverseRotation(eqjHor);
  const toENU=a=>{const h=rotate(eqjHor,a,date);return [-h[1],h[0],h[2]];};
  const fromENU=a=>rotate(horEqj,[a[1],-a[0],a[2]],date);
  const upEqj=fromENU([0,0,1]);
  const eastEqj=fromENU([1,0,0]);
  const northEqj=fromENU([0,1,0]);
  const skyBody=position=>{
    const relative=sub(position,observerEqj),uEqj=unit(relative);
    const enu=toENU(uEqj);
    return {az:wrap360(Math.atan2(enu[0],enu[1])*RAD),alt:Math.asin(clamp(enu[2]))*RAD,enu,uEqj,distanceAU:norm(relative),aboveHorizon:enu[2]>=0};
  };
  const moon=skyBody(moonEqj),sun=skyBody(sunEqj);
  const u=moon.uEqj,lightEqj=unit(sub(sunEqj,moonEqj));
  const orientation=horizonOrientation(u,lightEqj,upEqj,eastEqj);
  const {right:rightEqj,screenUp:screenUpEqj,brightAngle,terminatorAngle,angleStable}=orientation;
  return {date,lat,lon,latitude:lat,longitude:lon,observerEqj,moon,sun,lightEqj,lightENU:toENU(lightEqj),
    upEqj,eastEqj,northEqj,rightEqj,screenUpEqj,brightAngle,terminatorAngle,angleStable,
    illumination:clamp((1-dot(lightEqj,u))/2,0,1),
    geoIllumination:clamp((1-dot(lightEqj,unit(moonEqj)))/2,0,1),
    moonScreenLight:orientation.screenLight,
    moonDistanceKm:norm(moonEqj)*AU_KM,topocentricDistanceKm:moon.distanceAU*AU_KM,
    visibility:moon.alt<0?'地平線下':sun.alt>0?'白天：幾何可見不等於肉眼可見':sun.alt>-18?'薄暮／曙光：亮度影響可見性':'夜間：仍受天氣與地形影響',
    eqjToENU:toENU,enuToEQJ:fromENU};
}

/** Ephemeris event convention intentionally identical to MoonPhase/SearchMoonPhase. */
export function ephemeris(input,lat=24.15,lon=120.67){
  const date=asDate(input);
  if(!Number.isFinite(+date))throw new Error('日期無效');
  const mv=Astronomy.GeoVector(Astronomy.Body.Moon,date,false);
  const sv=Astronomy.GeoVector(Astronomy.Body.Sun,date,false);
  const moonEqj=vectorArray(mv),sunEqj=vectorArray(sv);
  const me=Astronomy.Ecliptic(mv),se=Astronomy.Ecliptic(sv);
  const geometry=observerGeometry(date,lat,lon,moonEqj,sunEqj);
  return {...geometry,moonEqj,sunEqj,moonEcl:vectorArray(me.vec),sunEcl:vectorArray(se.vec),
    deltaLon:Astronomy.MoonPhase(date),elongation:Math.acos(clamp(dot(unit(moonEqj),unit(sunEqj))))*RAD,
    beta:me.elat,moonLon:me.elon,sunLon:se.elon,
    obliquity:Astronomy.e_tilt(Astronomy.MakeTime(date)).tobl,
    siderealDeg:Astronomy.SiderealTime(date)*15,
    equatorialNorthEcl:eqjToEct(rotate(Astronomy.Rotation_EQD_EQJ(date),[0,0,1],date),date),
    lightEcl:eqjToEct(geometry.lightEqj,date),meanElements:meanElements(date),mode:'ephemeris'};
}

export function searchPhase(target,date,direction=1,limitDays=40){
  const found=Astronomy.SearchMoonPhase(wrap360(target),asDate(date),Math.sign(direction||1)*Math.abs(limitDays));
  if(!found)throw new Error('指定期間內找不到相位事件');
  return found.date;
}
const cycleCache=[];
export function lunation(input){
  const date=asDate(input),t=+date;
  const cached=cycleCache.find(c=>t>=+c.newMoon-50 && t<+c.nextNewMoon-50);
  if(cached)return cached;
  // A search near an exact root can select the prior lunation; recheck forward.
  let newMoon=searchPhase(0,shifted(date,0.00001),-1);
  if(+newMoon>t+1000)newMoon=searchPhase(0,shifted(newMoon,-1),-1);
  let nextNewMoon=searchPhase(0,shifted(newMoon,1),1);
  if(+nextNewMoon<t-50){newMoon=nextNewMoon;nextNewMoon=searchPhase(0,shifted(newMoon,1),1);}
  const result={newMoon,firstQuarter:searchPhase(90,shifted(newMoon,0.2)),fullMoon:searchPhase(180,shifted(newMoon,0.2)),lastQuarter:searchPhase(270,shifted(newMoon,0.2)),nextNewMoon};
  cycleCache.unshift(result);if(cycleCache.length>48)cycleCache.pop();
  return result;
}
export function lunarDay(date,newMoon,offsetHours=8){
  return Math.floor((+asDate(date)+offsetHours*DAY/24)/DAY)-Math.floor((+asDate(newMoon)+offsetHours*DAY/24)/DAY)+1;
}
export function lunarDayName(day){
  if(day<=10)return ['','初一','初二','初三','初四','初五','初六','初七','初八','初九','初十'][day]||String(day);
  if(day<20)return '十'+['','一','二','三','四','五','六','七','八','九'][day-10];
  if(day===20)return '二十';if(day<30)return '廿'+['','一','二','三','四','五','六','七','八','九'][day-20];
  return day===30?'三十':String(day);
}
export function samplePhaseCycle(newMoon,count=181){
  newMoon=asDate(newMoon);
  const next=searchPhase(0,shifted(newMoon,1)),duration=(next-newMoon)/DAY;
  let prev=0;
  return Array.from({length:count},(_,i)=>{
    const days=duration*i/(count-1),date=shifted(newMoon,days);
    let real=Astronomy.MoonPhase(date);
    if(i===0)real=0;
    while(real<prev-180)real+=360;
    if(i===count-1)real=360;
    prev=real;
    return {date,days,real,ideal:days*360/SYNODIC};
  });
}
const monthlyCache=new Map();
export function monthlyIntervals(date,count=25){
  const center=lunation(date).newMoon,key=`${+center}:${count}`;
  if(monthlyCache.has(key))return monthlyCache.get(key);
  let start=center;
  for(let i=0;i<Math.floor(count/2);i++)start=searchPhase(0,shifted(start,-1),-1);
  const rows=[];
  for(let i=0;i<count;i++){
    const firstQuarter=searchPhase(90,shifted(start,0.2));
    rows.push({newMoon:start,firstQuarter,days:(firstQuarter-start)/DAY,hours:(firstQuarter-start)/(DAY/24),lunarDay:lunarDay(firstQuarter,start,8)});
    start=searchPhase(0,shifted(start,1));
  }
  monthlyCache.set(key,rows);if(monthlyCache.size>8)monthlyCache.delete(monthlyCache.keys().next().value);
  return rows;
}
export function findLunarDayExamples(date=new Date(),count=121){
  const rows=monthlyIntervals(date,count),byDay={};
  for(const row of rows)if(!byDay[row.lunarDay])byDay[row.lunarDay]=row;
  return Object.values(byDay).sort((a,b)=>a.lunarDay-b.lunarDay);
}

/** Solve elliptic Kepler equation by Newton iteration, e restricted to sandbox range. */
export function solveKepler(meanAnomaly,e){
  e=clamp(Number(e),0,0.10);
  const M=((meanAnomaly+Math.PI)%(2*Math.PI)+2*Math.PI)%(2*Math.PI)-Math.PI;
  let E=M;
  for(let n=0;n<16;n++){
    const change=(E-e*Math.sin(E)-M)/(1-e*Math.cos(E));
    E-=change;if(Math.abs(change)<1e-14)break;
  }
  return E;
}
function cleanParams(p={}){
  return {e:clamp(Number(p.e??0.0549),0,0.10),i:clamp(Number(p.i??5.145),0,10),node:Number(p.node??p.Omega??125.045),peri:Number(p.peri??p.omega??318.15),phase:Number(p.phase??0),sunLon:Number(p.sunLon??0)};
}
function orientedOrbit(v,node,i,peri){
  const w=peri*DEG,O=node*DEG,I=i*DEG;
  const a=[Math.cos(w)*v[0]-Math.sin(w)*v[1],Math.sin(w)*v[0]+Math.cos(w)*v[1],0];
  const b=[a[0],a[1]*Math.cos(I),a[1]*Math.sin(I)];
  return [b[0]*Math.cos(O)-b[1]*Math.sin(O),b[0]*Math.sin(O)+b[1]*Math.cos(O),b[2]];
}
export function keplerState(days,parameters={}){
  const p=cleanParams(parameters),mean=p.phase*DEG+2*Math.PI*days/SIDEREAL,E=solveKepler(mean,p.e);
  const position=orientedOrbit([Math.cos(E)-p.e,Math.sqrt(1-p.e*p.e)*Math.sin(E),0],p.node,p.i,p.peri);
  const radius=1-p.e*Math.cos(E),trueAnomaly=wrap360(Math.atan2(Math.sqrt(1-p.e*p.e)*Math.sin(E),Math.cos(E)-p.e)*RAD);
  const dEdt=(2*Math.PI/SIDEREAL)/(1-p.e*Math.cos(E));
  const velocity=orientedOrbit([-Math.sin(E)*dEdt,Math.sqrt(1-p.e*p.e)*Math.cos(E)*dEdt,0],p.node,p.i,p.peri);
  const sunLon=wrap360(p.sunLon+360*days/YEAR),sun=[Math.cos(sunLon*DEG),Math.sin(sunLon*DEG),0];
  const moonLon=wrap360(Math.atan2(position[1],position[0])*RAD);
  return {position,velocity,sun,sunPosition:scale(sun,1/LUNAR_A),radius,E,meanAnomaly:wrap360(mean*RAD),trueAnomaly,moonLon,sunLon,
    deltaLon:wrap360(moonLon-sunLon),angularSpeed:norm(cross(position,velocity))/(radius*radius)*RAD,
    arealRate:norm(cross(position,velocity))/2,beta:Math.asin(clamp(position[2]/radius))*RAD,params:p};
}
/** Numerically root a target unwrapped longitude difference over the next model cycle. */
export function searchModelPhase(target,parameters={},startDays=0,limitDays=40){
  const desired=wrap360(target),step=0.125;
  let a=startDays,pa=keplerState(a,parameters).deltaLon;
  if(Math.abs(signed180(pa-desired))<1e-9)return a;
  let unwrapped=pa;
  const targetUnwrapped=desired+360*Math.ceil((pa-desired+1e-8)/360);
  for(let b=a+step;b<=startDays+limitDays+step/2;b+=step){
    const pb=keplerState(b,parameters).deltaLon;
    const next=unwrapped+signed180(pb-pa);
    if(unwrapped<=targetUnwrapped && next>=targetUnwrapped){
      let lo=a,hi=b;
      for(let j=0;j<45;j++){
        const mid=(lo+hi)/2,pm=keplerState(mid,parameters).deltaLon;
        const um=unwrapped+signed180(pm-pa);
        if(um<targetUnwrapped)lo=mid;else hi=mid;
      }
      return (lo+hi)/2;
    }
    a=b;pa=pb;unwrapped=next;
  }
  throw new Error('簡化模型相位搜尋超過範圍');
}
/** Align M at t=0 so all e/i/peri comparisons share the same new-moon start. */
export function alignedParams(parameters={},sunLon=0){
  const p=cleanParams({...parameters,sunLon});
  // Longitude is monotone for i<=10 and e<=0.10: solve phase root in mean anomaly.
  let lo=0,hi=360;
  const start=keplerState(0,{...p,phase:0}).moonLon;
  const target=wrap360(sunLon-start);
  if(target<1e-12)return {...p,phase:0};
  for(let k=0;k<55;k++){
    const phase=(lo+hi)/2;
    const advance=wrap360(keplerState(0,{...p,phase}).moonLon-start);
    if(advance<target)lo=phase;else hi=phase;
  }
  return {...p,phase:(lo+hi)/2};
}
export function sandboxQuarterInterval(parameters={},sunLon=0){
  const params=alignedParams(parameters,sunLon);
  const days=searchModelPhase(90,params,0.000001);
  return {days,hours:days*24,params,newMoonDays:0,firstQuarterDays:days};
}
export function compareModels(parameters={},sunLon=0){
  const ideal=sandboxQuarterInterval({e:0,i:0,node:0,peri:0,phase:0},sunLon);
  const ellipse=sandboxQuarterInterval(parameters,sunLon);
  return {ideal,ellipse,differenceHours:(ellipse.days-ideal.days)*24};
}

export function idealState(date,anchorNewMoon){
  const anchor=anchorNewMoon?asDate(anchorNewMoon):lunation(date).newMoon;
  const anchorSun=Astronomy.Ecliptic(Astronomy.GeoVector(Astronomy.Body.Sun,anchor,false)).elon;
  const days=(+asDate(date)-anchor)/DAY;
  const state=keplerState(days,{e:0,i:0,node:0,peri:0,phase:anchorSun,sunLon:anchorSun});
  const moonEcl=scale(state.position,LUNAR_A),sunEcl=state.sun;
  return {...state,date:asDate(date),days,moonEcl,sunEcl,moonEqj:ectToEqj(moonEcl,date),sunEqj:ectToEqj(sunEcl,date),mode:'ideal'};
}
export function modelTopocentric(date,lat,lon,parameters={},anchorNewMoon){
  date=asDate(date);
  const anchor=anchorNewMoon?asDate(anchorNewMoon):lunation(date).newMoon;
  const anchorSun=Astronomy.Ecliptic(Astronomy.GeoVector(Astronomy.Body.Sun,anchor,false)).elon;
  const raw=cleanParams(parameters);
  const base=alignedParams(raw,anchorSun);
  const p=parameters.rawPhase?{...raw,sunLon:anchorSun}:{...base,phase:base.phase+raw.phase};
  const days=(date-anchor)/DAY,state=keplerState(days,p);
  const moonEcl=scale(state.position,LUNAR_A),sunEcl=state.sun;
  const moonEqj=ectToEqj(moonEcl,date),sunEqj=ectToEqj(sunEcl,date);
  const geometry=observerGeometry(date,lat,lon,moonEqj,sunEqj);
  return {...state,...geometry,date,days,moonEcl,sunEcl,moonEqj,sunEqj,
    elongation:Math.acos(clamp(dot(unit(moonEqj),unit(sunEqj))))*RAD,
    obliquity:Astronomy.e_tilt(Astronomy.MakeTime(date)).tobl,
    siderealDeg:Astronomy.SiderealTime(date)*15,
    lightEcl:eqjToEct(geometry.lightEqj,date),meanElements:p,mode:'sandbox'};
}

const trajectoryCache=new Map();
/** Hourly true trajectory in a single selected-date ECT reference frame, not a fixed ellipse. */
export function trajectory(date,beforeDays=16,afterDays=16,stepHours=1){
  date=asDate(date);const key=`${Math.floor(+date/DAY)}:${beforeDays}:${afterDays}:${stepHours}`;
  if(trajectoryCache.has(key))return trajectoryCache.get(key);
  const rotation=Astronomy.Rotation_EQJ_ECT(date),points=[];
  for(let h=-beforeDays*24;h<=afterDays*24+1e-6;h+=stepHours){
    const at=shifted(date,h/24),eqj=vectorArray(Astronomy.GeoMoon(at));
    const position=rotate(rotation,eqj,at);
    points.push({date:at,position,eqj,beta:Math.asin(clamp(position[2]/norm(position)))*RAD});
  }
  trajectoryCache.set(key,points);if(trajectoryCache.size>5)trajectoryCache.delete(trajectoryCache.keys().next().value);
  return points;
}
export function meanElements(date){
  const t=Astronomy.MakeTime(date).tt/36525;
  const node=wrap360(125.04452-1934.136261*t+0.0020708*t*t+t*t*t/450000);
  const longitudePerigee=wrap360(83.3532465+4069.0137287*t-0.01032*t*t-t*t*t/80053);
  const meanLongitude=wrap360(218.3164477+481267.88123421*t-0.0015786*t*t+t*t*t/538841);
  return {e:0.0549,i:5.145,node,peri:wrap360(longitudePerigee-node),phase:wrap360(meanLongitude-longitudePerigee),sunLon:0};
}
export function meanOrbit(date,count=180){
  const params=meanElements(date);
  const points=Array.from({length:count+1},(_,j)=>scale(keplerState(SIDEREAL*j/count,{...params,phase:0}).position,LUNAR_A));
  const atNu=nu=>{
    const r=(1-params.e*params.e)/(1+params.e*Math.cos(nu*DEG));
    return scale(orientedOrbit([r*Math.cos(nu*DEG),r*Math.sin(nu*DEG),0],params.node,params.i,params.peri),LUNAR_A);
  };
  return {points,params,inclination:params.i,node:params.node,peri:params.peri,ascending:atNu(-params.peri),descending:atNu(180-params.peri),perigee:atNu(0),apogee:atNu(180),label:'平均元素幾何示意，非精確瞬時攝動軌道'};
}

/** Equator/ecliptic unit great circles expressed in the observer's ENU frame. */
export function skyReferenceCurves(snapshot,count=180){
  const date=snapshot.date,toENU=snapshot.eqjToENU;
  const ecliptic=[],equator=[];
  for(let i=0;i<=count;i++){
    const p=[Math.cos(2*Math.PI*i/count),Math.sin(2*Math.PI*i/count),0];
    ecliptic.push(toENU(ectToEqj(p,date)));
    equator.push(toENU(rotate(Astronomy.Rotation_EQD_EQJ(date),p,date)));
  }
  return {ecliptic,equator};
}
