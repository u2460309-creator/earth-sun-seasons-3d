/**
 * Observer-centred views.  Input EQJ vectors are in one common inertial frame;
 * ENU arrays are [east,north,up].  Three's scene mapping is (E,U,-N).
 * Textures are original procedural artwork, with no external assets.
 */
import * as THREE from 'three';
import * as Astronomy from 'astronomy-engine';

const DEG = Math.PI / 180;
const TAU = 2 * Math.PI;
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const neg = a => a.map(x => -x);
const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
const enuWorld = a => new THREE.Vector3(a[0], a[2], -a[1]);
const safeUnit = a => {
  const m = Math.hypot(...a);
  return m > 1e-12 ? a.map(x => x / m) : [0, 0, 1];
};

function rendererFor(canvas) {
  const r = new THREE.WebGLRenderer({canvas, antialias: true, alpha: false, preserveDrawingBuffer: true});
  r.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  r.outputColorSpace = THREE.SRGBColorSpace;
  r.setClearColor(0x08111e, 1);
  return r;
}

function label(text, color = '#cbdbea', scale = 1, _width = 512, cssPixels = 12) {
  // Tight glyph bounds and a CSS-pixel target avoid tiny text on large textures.
  const c = document.createElement('canvas');
  let ctx = c.getContext('2d');
  const font = '600 52px "Microsoft JhengHei", "Noto Sans TC", sans-serif';
  ctx.font = font;
  const measure = ctx.measureText(text);
  const ascent = Math.ceil(measure.actualBoundingBoxAscent || 48);
  const descent = Math.ceil(measure.actualBoundingBoxDescent || 8);
  const padding = 9;
  const glyphHeight = ascent + descent;
  c.width = Math.ceil(measure.width) + padding * 2;
  c.height = glyphHeight + padding * 2;
  ctx = c.getContext('2d');
  ctx.font = font;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'alphabetic';
  ctx.lineJoin = 'round';
  ctx.lineWidth = 6;
  ctx.strokeStyle = '#06101e';
  ctx.strokeText(text, c.width / 2, padding + ascent);
  ctx.fillStyle = color;
  ctx.fillText(text, c.width / 2, padding + ascent);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  const material = new THREE.SpriteMaterial({map: tex, transparent: true, depthTest: false, depthWrite: false});
  const sprite = new THREE.Sprite(material);
  sprite.scale.set(scale * c.width / c.height, scale, 1);
  sprite.userData.text = text;
  sprite.userData.labelMetrics = {aspect: c.width / c.height, glyphFraction: glyphHeight / c.height, cssPixels};
  return sprite;
}

function disposeObject(obj) {
  obj.traverse(o => {
    if (o.geometry) o.geometry.dispose();
    const mats = Array.isArray(o.material) ? o.material : o.material ? [o.material] : [];
    for (const mat of mats) {
      if (mat.map) mat.map.dispose();
      if (mat.uniforms?.surface?.value) mat.uniforms.surface.value.dispose();
      mat.dispose();
    }
  });
}

function curve(points, color, {dashed = false, opacity = 1} = {}) {
  const geometry = new THREE.BufferGeometry().setFromPoints(points);
  const material = dashed
    ? new THREE.LineDashedMaterial({color, transparent: opacity < 1, opacity, dashSize: 1.2, gapSize: .8})
    : new THREE.LineBasicMaterial({color, transparent: opacity < 1, opacity});
  const line = new THREE.Line(geometry, material);
  if (dashed) line.computeLineDistances();
  return line;
}

function replaceCurve(parent, old, points, color, options) {
  if (old) { parent.remove(old); disposeObject(old); }
  const item = curve(points, color, options);
  parent.add(item);
  return item;
}

function moonTexture() {
  const size = 512;
  const c = document.createElement('canvas');
  c.width = size; c.height = size / 2;
  const ctx = c.getContext('2d');
  let seed = 0x5103aa;
  const rand = () => {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    return seed / 4294967296;
  };
  ctx.fillStyle = '#b7b8b7'; ctx.fillRect(0, 0, c.width, c.height);
  // Tonal maria and craters are schematic original artwork, not a lunar map.
  for (let i = 0; i < 30; i++) {
    const x = rand() * size, y = rand() * c.height;
    const radius = 10 + rand() * 40;
    const g = ctx.createRadialGradient(x, y, 0, x, y, radius);
    g.addColorStop(0, 'rgba(59,65,67,.30)'); g.addColorStop(1, 'rgba(59,65,67,0)');
    ctx.fillStyle = g; ctx.fillRect(x - radius, y - radius, radius * 2, radius * 2);
  }
  for (let i = 0; i < 1100; i++) {
    const x = rand() * size, y = rand() * c.height;
    const radius = .35 + rand() ** 3 * 6;
    ctx.beginPath(); ctx.arc(x, y, radius, 0, TAU);
    ctx.fillStyle = `rgba(60,65,67,${.06 + rand() * .15})`; ctx.fill();
    ctx.beginPath(); ctx.arc(x - radius * .12, y - radius * .12, radius, .15, 3.7);
    ctx.strokeStyle = 'rgba(237,239,230,.27)'; ctx.lineWidth = .6; ctx.stroke();
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  return tex;
}

function moonMaterial() {
  return new THREE.ShaderMaterial({
    uniforms: {lightDirection: {value: new THREE.Vector3(1, 0, 0)}, surface: {value: moonTexture()}, earthshine: {value: .014}},
    vertexShader: `varying vec3 vNormal; varying vec2 vUv;
      void main(){vNormal=normalize(mat3(modelMatrix)*normal);vUv=uv;
      gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}`,
    fragmentShader: `uniform vec3 lightDirection; uniform sampler2D surface; uniform float earthshine;
      varying vec3 vNormal; varying vec2 vUv;
      void main(){float incidence=max(dot(normalize(vNormal),normalize(lightDirection)),0.0);
      vec3 albedo=texture2D(surface,vUv).rgb;
      gl_FragColor=vec4(albedo*(earthshine+1.12*incidence),1.0);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
      }`
  });
}

class BaseView {
  resize() {
    const rect = this.canvas.getBoundingClientRect();
    const width = Math.max(1, Math.round(rect.width || this.canvas.clientWidth || 600));
    const height = Math.max(1, Math.round(rect.height || this.canvas.clientHeight || 400));
    if (width === this.width && height === this.height) return;
    this.width = width; this.height = height;
    this.renderer.setSize(width, height, false);
    const aspect = width / height;
    if (this.camera.isPerspectiveCamera) this.camera.aspect = aspect;
    else {
      const h = aspect < 1 ? 1.64 / aspect : 1.64;
      this.camera.left = -h * aspect;
      this.camera.right = h * aspect;
      this.camera.top = h;
      this.camera.bottom = -h;
    }
    this.camera.updateProjectionMatrix();
  }
  render() {
    this.resize();
    this.scene.updateMatrixWorld(true);
    this.camera.updateMatrixWorld(true);
    const position = new THREE.Vector3();
    this.scene.traverse(object => {
      const metrics = object.userData.labelMetrics;
      if (!metrics || !object.visible) return;
      let pixelsPerWorld;
      if (this.camera.isOrthographicCamera) pixelsPerWorld = this.height / (this.camera.top - this.camera.bottom);
      else {
        object.getWorldPosition(position).applyMatrix4(this.camera.matrixWorldInverse);
        const depth = Math.max(.1, -position.z);
        pixelsPerWorld = this.height / (2 * Math.tan(this.camera.fov * DEG / 2) * depth);
      }
      const worldHeight = metrics.cssPixels / (metrics.glyphFraction * pixelsPerWorld);
      object.scale.set(worldHeight * metrics.aspect, worldHeight, 1);
    });
    this.renderer.render(this.scene, this.camera);
  }
  dispose() {
    if (this.observer) this.observer.disconnect();
    if (this.abort) this.abort.abort();
    disposeObject(this.scene);
    this.renderer.dispose();
  }
  watchSize() {
    if (typeof ResizeObserver !== 'undefined') {
      this.observer = new ResizeObserver(() => this.render());
      this.observer.observe(this.canvas);
    }
  }
}

/** A real sphere, orthographically projected into the observer's tangent plane. */
export class MoonView extends BaseView {
  constructor(canvas) {
    super();
    this.canvas = canvas;
    this.renderer = rendererFor(canvas);
    this.scene = new THREE.Scene();
    this.camera = new THREE.OrthographicCamera(-2, 2, 1.64, -1.64, .1, 20);
    this.camera.position.set(0, 0, 6);
    this.camera.lookAt(0, 0, 0);
    this.material = moonMaterial();
    this.moon = new THREE.Mesh(new THREE.SphereGeometry(1, 112, 80), this.material);
    this.scene.add(this.moon);
    const ringPoints = [];
    for (let i = 0; i <= 128; i++) ringPoints.push(new THREE.Vector3(1.035 * Math.cos(i * TAU / 128), 1.035 * Math.sin(i * TAU / 128), -.04));
    this.scene.add(curve(ringPoints, 0x31445c));
    this.vertical = curve([new THREE.Vector3(0, -1.27, -.02), new THREE.Vector3(0, 1.28, -.02)], 0x6d879e, {dashed: true, opacity: .55});
    // Short dash lengths suit the orthographic close-up.
    this.vertical.material.dashSize = .045;
    this.vertical.material.gapSize = .045;
    this.scene.add(this.vertical);
    const horizontal = curve([new THREE.Vector3(-1.3, 0, -.02), new THREE.Vector3(1.3, 0, -.02)], 0x40576e, {dashed: true, opacity: .35});
    horizontal.material.dashSize = .045; horizontal.material.gapSize = .045;
    this.scene.add(horizontal);
    this.upLabel = label('本地鉛直 ↑', '#b9d1e4', .105, 384, 13);
    this.upLabel.position.set(0, 1.46, .1); this.scene.add(this.upLabel);
    this.rightLabel = label('右 →', '#b9d1e4', .1, 256, 12);
    this.rightLabel.position.set(1.34, -.12, .2); this.scene.add(this.rightLabel);
    this.sunArrow = new THREE.ArrowHelper(new THREE.Vector3(1, 0, 0), new THREE.Vector3(1.1, 0, .15), .35, 0xffd176, .11, .065);
    this.scene.add(this.sunArrow);
    this.sunLabel = label('亮側朝太陽', '#ffd176', .105, 384, 12);
    this.sunLabel.position.set(.6, -1.46, .2); this.scene.add(this.sunLabel);
    this.orientationLabel = label('地平線水平・右方為觀測者右方', '#a3b9cc', .09, 800, 12);
    this.orientationLabel.position.set(0, -1.24, .2); this.scene.add(this.orientationLabel);
    this.unstableLabel = label('角度此時不穩定／未定義', '#f5ba74', .12, 800);
    this.unstableLabel.position.set(0, -1.47, .3); this.unstableLabel.visible = false;
    this.scene.add(this.unstableLabel);
    this.watchSize();
    this.render();
  }
  update(snapshot, options = {}) {
    this.snapshot = snapshot;
    const u = snapshot.moon?.uEqj || safeUnit(snapshot.moonEqj || [1, 0, 0]);
    const right = snapshot.rightEqj || [0, 1, 0];
    const up = snapshot.screenUpEqj || snapshot.upEqj || [0, 0, 1];
    const light = snapshot.lightEqj || [1, 0, 0];
    const localLight = [dot(light, right), dot(light, up), dot(light, neg(u))];
    this.material.uniforms.lightDirection.value.set(...localLight).normalize();
    this.material.uniforms.earthshine.value = options.earthshine === false ? 0 : .014;
    const xy = Math.hypot(localLight[0], localLight[1]);
    const stable = snapshot.angleStable !== false && xy > 1e-6;
    this.sunArrow.visible = stable;
    this.unstableLabel.visible = !stable;
    this.sunLabel.visible = stable;
    if (stable) {
      const dir = new THREE.Vector3(localLight[0] / xy, localLight[1] / xy, 0);
      this.sunArrow.position.copy(dir).multiplyScalar(1.12); this.sunArrow.position.z = .16;
      this.sunArrow.setDirection(dir);
      const labelX = clamp(dir.x * .75, -.65, .65);
      const labelY = -1.47;
      this.sunLabel.position.set(labelX, labelY, .2);
    }
    this.vertical.visible = options.guides !== false;
    this.render();
  }
}

/** A horizon-locked camera within an observer-centred ENU celestial sphere. */
export class SkyView extends BaseView {
  constructor(canvas) {
    super();
    this.canvas = canvas;
    this.renderer = rendererFor(canvas);
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x07101c);
    this.camera = new THREE.PerspectiveCamera(92, 1, .1, 160);
    this.camera.position.set(0, 0, 0);
    this.camera.up.set(0, 1, 0);
    this.azimuth = 180;
    this.altitude = 28;
    this.follow = true;
    this.manual = false;
    this.options = {};
    this.abort = new AbortController();
    this.canvas.style.touchAction = 'none';
    this.referenceGroup = new THREE.Group(); this.scene.add(this.referenceGroup);
    this.buildSky();
    this.moonMaterial = moonMaterial();
    this.moon = new THREE.Mesh(new THREE.SphereGeometry(1.4, 48, 32), this.moonMaterial);
    this.scene.add(this.moon);
    this.sun = new THREE.Mesh(new THREE.SphereGeometry(1.2, 32, 20), new THREE.MeshBasicMaterial({color: 0xffd391}));
    this.scene.add(this.sun);
    this.moonLabel = label('月球（視直徑放大）', '#e8eef6', 2, 640, 13); this.scene.add(this.moonLabel);
    this.sunLabel = label('太陽', '#ffd176', 2, 320, 13); this.scene.add(this.sunLabel);
    this.belowSunLabel = label('太陽在地平線下 ↓', '#d6a563', 1.7, 640); this.scene.add(this.belowSunLabel);
    this.bindControls();
    this.watchSize();
    this.updateCamera(); this.render();
  }
  buildSky() {
    // Original deterministic star field; no constellation/astrometric claims.
    const starPoints = [];
    let seed = 1367;
    const random = () => {seed = Math.imul(seed, 1664525) + 1013904223 | 0; return (seed >>> 0) / 4294967296;};
    for (let i = 0; i < 760; i++) {
      const z = 2 * random() - 1, a = TAU * random(), r = Math.sqrt(1 - z * z);
      starPoints.push(100 * r * Math.cos(a), 100 * z, 100 * r * Math.sin(a));
    }
    const starGeometry = new THREE.BufferGeometry();
    starGeometry.setAttribute('position', new THREE.Float32BufferAttribute(starPoints, 3));
    this.stars = new THREE.Points(starGeometry, new THREE.PointsMaterial({color: 0x8093a8, size: .16, sizeAttenuation: true}));
    this.scene.add(this.stars);
    const groundGeometry = new THREE.SphereGeometry(57, 96, 48, 0, TAU, Math.PI / 2, Math.PI / 2);
    this.ground = new THREE.Mesh(groundGeometry, new THREE.MeshBasicMaterial({color: 0x14222c, side: THREE.BackSide}));
    this.scene.add(this.ground);
    this.gridGroup = new THREE.Group(); this.scene.add(this.gridGroup);
    for (const alt of [0, 15, 30, 45, 60, 75]) {
      const points = [];
      for (let i = 0; i <= 144; i++) {
        const az = i * TAU / 144, a = alt * DEG;
        points.push(new THREE.Vector3(56 * Math.cos(a) * Math.sin(az), 56 * Math.sin(a), -56 * Math.cos(a) * Math.cos(az)));
      }
      this.gridGroup.add(curve(points, alt === 0 ? 0x8caa9e : 0x263b4c, {opacity: alt === 0 ? .9 : .65}));
    }
    for (let az = 0; az < 360; az += 30) {
      const points = [];
      for (let i = 0; i <= 36; i++) {
        const a = i / 36 * Math.PI / 2;
        points.push(new THREE.Vector3(56 * Math.cos(a) * Math.sin(az * DEG), 56 * Math.sin(a), -56 * Math.cos(a) * Math.cos(az * DEG)));
      }
      this.gridGroup.add(curve(points, 0x263b4c, {opacity: .6}));
    }
    this.labelsGroup = new THREE.Group(); this.scene.add(this.labelsGroup);
    for (const [text, az] of [['北 N', 0], ['東 E', 90], ['南 S', 180], ['西 W', 270]]) {
      const item = label(text, '#d4e8ed', 3.2, 256, 18);
      item.position.set(53 * Math.sin(az * DEG), 2, -53 * Math.cos(az * DEG));
      this.labelsGroup.add(item);
    }
    const zenith = label('天頂 +90°', '#c0d6e4', 2.5, 384, 14);
    zenith.position.set(0, 53, 0); zenith.center.set(.5, 1); this.labelsGroup.add(zenith);
    const horizon = label('地平線 0°', '#b9d5cb', 1.7, 384, 13);
    horizon.position.set(40, .8, -33); this.labelsGroup.add(horizon);
  }
  bindControls() {
    const signal = this.abort.signal;
    this.pointers = new Map();
    this.canvas.addEventListener('pointerdown', e => {
      this.canvas.setPointerCapture(e.pointerId);
      this.pointers.set(e.pointerId, {x: e.clientX, y: e.clientY});
      this.manual = true;
      if (this.onManual) this.onManual();
    }, {signal});
    this.canvas.addEventListener('pointermove', e => {
      const old = this.pointers.get(e.pointerId);
      if (!old) return;
      const dx = e.clientX - old.x, dy = e.clientY - old.y;
      if (this.pointers.size === 1) {
        this.azimuth -= dx * this.camera.fov / Math.max(200, this.width || 600);
        this.altitude = clamp(this.altitude + dy * this.camera.fov / Math.max(200, this.height || 400), -85, 89.8);
      } else {
        const other = [...this.pointers.entries()].find(([id]) => id !== e.pointerId)?.[1];
        if (other) {
          const prevDistance = Math.hypot(old.x - other.x, old.y - other.y);
          const distance = Math.hypot(e.clientX - other.x, e.clientY - other.y);
          if (distance > 0) this.camera.fov = clamp(this.camera.fov * prevDistance / distance, 25, 115);
        }
      }
      this.pointers.set(e.pointerId, {x: e.clientX, y: e.clientY});
      this.updateCamera(); this.render();
    }, {signal});
    const release = e => this.pointers.delete(e.pointerId);
    this.canvas.addEventListener('pointerup', release, {signal});
    this.canvas.addEventListener('pointercancel', release, {signal});
    this.canvas.addEventListener('wheel', e => {
      e.preventDefault();
      this.camera.fov = clamp(this.camera.fov * Math.exp(e.deltaY * .001), 25, 115);
      this.updateCamera(); this.render();
    }, {signal, passive: false});
  }
  updateCamera() {
    const az = this.azimuth * DEG, alt = this.altitude * DEG;
    this.camera.lookAt(Math.cos(alt) * Math.sin(az), Math.sin(alt), -Math.cos(alt) * Math.cos(az));
    this.camera.updateProjectionMatrix();
  }
  setFollow(value = true) {
    this.follow = value; this.manual = false;
    if (this.snapshot) this.update(this.snapshot, {...this.options, follow: value});
  }
  setView(view) {
    this.manual = view !== 'moon';
    if (view === 'moon') this.setFollow(true);
    else {
      const az = {north: 0, east: 90, south: 180, west: 270}[view];
      if (az != null) this.azimuth = az;
      this.altitude = view === 'zenith' ? 89.5 : 24;
      this.updateCamera(); this.render();
    }
  }
  reset() { this.camera.fov = 92; this.manual = false; this.setFollow(true); }
  referencePaths(snapshot) {
    const date = snapshot.date instanceof Date ? snapshot.date : new Date(snapshot.date);
    const lat = snapshot.latitude ?? snapshot.lat ?? 24.15;
    const lon = snapshot.longitude ?? snapshot.lon ?? 120.67;
    const observer = new Astronomy.Observer(lat, lon, 0);
    const toHor = Astronomy.Rotation_EQJ_HOR(date, observer);
    const ectToEqj = Astronomy.Rotation_ECT_EQJ(date);
    const eqdToEqj = Astronomy.Rotation_EQD_EQJ(date);
    const makePath = rotation => {
      const points = [];
      for (let j = 0; j <= 144; j++) {
        const a = j / 144 * TAU;
        const input = new Astronomy.Vector(Math.cos(a), Math.sin(a), 0, date);
        const eqj = Astronomy.RotateVector(rotation, input);
        const hor = Astronomy.RotateVector(toHor, eqj);
        // HOR [north,west,up] -> Three [east,up,-north].
        points.push(new THREE.Vector3(-hor.y * 59, hor.z * 59, -hor.x * 59));
      }
      return points;
    };
    this.eclipticLine = replaceCurve(this.referenceGroup, this.eclipticLine, makePath(ectToEqj), 0xd5ad5b, {dashed: true, opacity: .8});
    this.equatorLine = replaceCurve(this.referenceGroup, this.equatorLine, makePath(eqdToEqj), 0x58acc5, {dashed: true, opacity: .75});
  }
  greatCircle(snapshot) {
    const m = enuWorld(snapshot.moon.enu).normalize();
    const s = enuWorld(snapshot.sun.enu).normalize();
    const theta = Math.acos(clamp(m.dot(s), -1, 1));
    const points = [];
    const sin = Math.sin(theta);
    if (Math.abs(sin) < 1e-6) {
      const fallback = new THREE.Vector3().crossVectors(m, new THREE.Vector3(0, 1, 0));
      if (fallback.lengthSq() < 1e-8) fallback.set(1, 0, 0);
      fallback.normalize();
      for (let i = 0; i <= 90; i++) {
        const a = i / 90 * Math.max(theta, .005);
        points.push(m.clone().multiplyScalar(Math.cos(a)).addScaledVector(fallback, Math.sin(a)).multiplyScalar(52));
      }
    } else {
      for (let i = 0; i <= 90; i++) {
        const t = i / 90;
        points.push(m.clone().multiplyScalar(Math.sin((1 - t) * theta) / sin).addScaledVector(s, Math.sin(t * theta) / sin).normalize().multiplyScalar(52));
      }
    }
    this.greatCircleLine = replaceCurve(this.scene, this.greatCircleLine, points, 0xffd176, {dashed: true, opacity: .8});
  }
  update(snapshot, options = {}) {
    this.snapshot = snapshot;
    const wasFollow = this.options.follow;
    this.options = {...this.options, ...options};
    if (options.follow === true && wasFollow === false) this.manual = false;
    this.follow = this.options.follow !== false;
    const moonDir = enuWorld(snapshot.moon.enu).normalize();
    const sunDir = enuWorld(snapshot.sun.enu).normalize();
    this.moon.position.copy(moonDir).multiplyScalar(60);
    this.sun.position.copy(sunDir).multiplyScalar(70);
    this.moonMaterial.uniforms.lightDirection.value.copy(enuWorld(snapshot.lightENU || [1, 0, 0])).normalize();
    const below = this.options.below === true;
    this.moon.visible = snapshot.moon.alt >= 0 || below;
    this.sun.visible = snapshot.sun.alt >= 0 || below;
    this.moonLabel.visible = this.moon.visible;
    this.sunLabel.visible = this.sun.visible;
    this.moonLabel.position.copy(moonDir).multiplyScalar(58); this.moonLabel.position.y += 3.6;
    this.sunLabel.position.copy(sunDir).multiplyScalar(58); this.sunLabel.position.y += 3;
    this.belowSunLabel.visible = snapshot.sun.alt < 0 && this.options.greatCircle !== false;
    this.belowSunLabel.position.copy(sunDir).multiplyScalar(50); this.belowSunLabel.position.y += 2;
    this.ground.material.transparent = below;
    this.ground.material.opacity = below ? .18 : 1;
    this.ground.material.depthWrite = !below;
    this.referencePaths(snapshot);
    this.eclipticLine.visible = this.options.ecliptic !== false;
    this.equatorLine.visible = this.options.equator !== false;
    this.greatCircle(snapshot);
    this.greatCircleLine.visible = this.options.greatCircle !== false;
    // Daylight changes sky luminance but does not claim naked-eye visibility.
    const day = clamp((snapshot.sun.alt + 12) / 32, 0, 1);
    this.scene.background.setRGB(.025 + .025 * day, .045 + .045 * day, .075 + .075 * day);
    this.stars.material.opacity = 1 - .9 * day;
    this.stars.material.transparent = true;
    if (this.follow && !this.manual) {
      this.azimuth = snapshot.moon.az;
      this.altitude = clamp(snapshot.moon.alt, below ? -85 : 3, 89.8);
    }
    this.updateCamera(); this.render();
  }
}
