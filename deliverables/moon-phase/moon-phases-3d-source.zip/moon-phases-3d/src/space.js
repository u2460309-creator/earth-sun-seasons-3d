import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

// Input vectors are AU, in the ecliptic frame of the observation date.
// Right-handed Three world: (X,Y,Z) = (ecliptic x, ecliptic z, -ecliptic y).
const AU_KM = 149597870.7;
const LUNAR_AU = 384400 / AU_KM;
const ORBIT = 9;
const D = Math.PI / 180;
const C = { real:0x54d6ee, ideal:0x83edb0, mean:0xc69af9, equator:0xf8b96b, ecliptic:0x497ca4 };
const clamp = (x,a,b) => Math.min(b,Math.max(a,x));
function world(v, exaggeration=1) {
  return new THREE.Vector3(v[0]/LUNAR_AU*ORBIT, v[2]/LUNAR_AU*ORBIT*exaggeration, -v[1]/LUNAR_AU*ORBIT);
}
function orbital(nu, e, i, node, peri) {
  const r=LUNAR_AU*(1-e*e)/(1+e*Math.cos(nu));
  const a=nu+peri*D, c=Math.cos(a), s=Math.sin(a), N=node*D, I=i*D;
  return [r*(Math.cos(N)*c-Math.sin(N)*s*Math.cos(I)), r*(Math.sin(N)*c+Math.cos(N)*s*Math.cos(I)), r*s*Math.sin(I)];
}
function texture(draw,w=1024,h=512) {
  const c=document.createElement('canvas'); c.width=w;c.height=h;
  draw(c.getContext('2d'),w,h);
  const t=new THREE.CanvasTexture(c); t.colorSpace=THREE.SRGBColorSpace;return t;
}
function earthTexture() {
  return texture((g,w,h)=>{
    const ocean=g.createLinearGradient(0,0,0,h);ocean.addColorStop(0,'#34789b');ocean.addColorStop(.45,'#174a7d');ocean.addColorStop(1,'#113d65');
    g.fillStyle=ocean;g.fillRect(0,0,w,h);
    // Original simplified hand-drawn geographic silhouettes, not downloaded maps.
    const lands=[[[.05,.18],[.11,.12],[.2,.15],[.28,.25],[.23,.35],[.19,.37],[.17,.46],[.13,.42],[.09,.30]],[[.20,.46],[.25,.47],[.29,.55],[.27,.66],[.25,.81],[.21,.86],[.20,.69],[.18,.56]],[[.44,.24],[.51,.18],[.56,.23],[.59,.31],[.56,.38],[.50,.37],[.47,.30]],[[.46,.36],[.53,.34],[.59,.44],[.57,.57],[.54,.68],[.49,.67],[.45,.53]],[[.56,.20],[.65,.13],[.76,.16],[.83,.26],[.89,.30],[.83,.40],[.73,.43],[.67,.35],[.60,.35]],[[.68,.37],[.72,.40],[.75,.54],[.71,.58]],[[.80,.62],[.86,.57],[.91,.64],[.89,.73],[.82,.74]],[[.35,.10],[.40,.12],[.39,.22],[.35,.24]]];
    lands.forEach((p,k)=>{g.fillStyle=k%2?'#71845a':'#6f946c';g.beginPath();p.forEach(([x,y],j)=>j?g.lineTo(x*w,y*h):g.moveTo(x*w,y*h));g.closePath();g.fill();});
    g.fillStyle='#cadce0';g.fillRect(0,0,w,h*.055);g.beginPath();g.moveTo(0,h*.93);for(let x=0;x<=w;x+=12)g.lineTo(x,h*(.925+.015*Math.sin(x*.035)));g.lineTo(w,h);g.lineTo(0,h);g.fill();
    g.strokeStyle='rgba(210,239,247,.17)';g.lineWidth=1;
    for(let x=0;x<w;x+=w/12){g.beginPath();g.moveTo(x,0);g.lineTo(x,h);g.stroke();}
    for(let y=h/6;y<h;y+=h/6){g.beginPath();g.moveTo(0,y);g.lineTo(w,y);g.stroke();}
  });
}
function moonTexture() {
  return texture((g,w,h)=>{
    g.fillStyle='#c8ccd0';g.fillRect(0,0,w,h);let seed=1729;
    const rand=()=>{seed=(1664525*seed+1013904223)>>>0;return seed/4294967296;};
    for(let i=0;i<40;i++){const x=rand()*w,y=rand()*h,r=10+rand()*60;g.fillStyle=`rgba(73,84,98,${.05+rand()*.13})`;g.beginPath();g.ellipse(x,y,r,r*.7,rand()*Math.PI,0,Math.PI*2);g.fill();}
    for(let i=0;i<350;i++){const x=rand()*w,y=rand()*h,r=1+rand()*9;g.strokeStyle='rgba(232,235,237,.45)';g.lineWidth=1;g.beginPath();g.ellipse(x,y,r,r*.8,0,0,Math.PI*2);g.stroke();g.fillStyle='rgba(60,68,80,.13)';g.beginPath();g.ellipse(x+1,y+1,r*.75,r*.6,0,0,Math.PI*2);g.fill();}
  });
}
function setLabelText(sprite,text,color='#dcebf6') {
  if(sprite.userData.text===text&&sprite.userData.color===color)return;
  const canvas=document.createElement('canvas'),font='500 30px system-ui, sans-serif';
  const measurement=canvas.getContext('2d');measurement.font=font;
  canvas.width=Math.ceil(measurement.measureText(text).width)+26;canvas.height=48;
  const g=canvas.getContext('2d');g.fillStyle='rgba(5,14,28,.91)';g.beginPath();g.roundRect(1,1,canvas.width-2,46,9);g.fill();
  g.font=font;g.textAlign='center';g.textBaseline='middle';g.fillStyle=color;g.fillText(text,canvas.width/2,24);
  const t=new THREE.CanvasTexture(canvas);t.colorSpace=THREE.SRGBColorSpace;
  sprite.material.map?.dispose();sprite.material.map=t;sprite.material.needsUpdate=true;
  Object.assign(sprite.userData,{text,color,aspect:canvas.width/canvas.height,cssHeight:48*12/30});
}
function label(text,color='#dcebf6',_legacyWorldWidth=3.5) {
  // sizeAttenuation:false + render-time viewport scaling keeps 12 CSS px text
  // legible regardless of zoom, camera distance, or dual/single view size.
  const s=new THREE.Sprite(new THREE.SpriteMaterial({transparent:true,depthTest:false,depthWrite:false,sizeAttenuation:false}));
  setLabelText(s,text,color);s.renderOrder=10;return s;
}
function line(points,color,opacity=.8,dashed=false) {
  const mat=dashed?new THREE.LineDashedMaterial({color,transparent:true,opacity,dashSize:.24,gapSize:.16}):new THREE.LineBasicMaterial({color,transparent:true,opacity});
  const l=new THREE.Line(new THREE.BufferGeometry().setFromPoints(points),mat);if(dashed)l.computeLineDistances();return l;
}
function replaceGeometry(object,points) {object.geometry.dispose();object.geometry=new THREE.BufferGeometry().setFromPoints(points);if(object.isLine&&object.material.isLineDashedMaterial)object.computeLineDistances();}
function finiteVector(v){return Array.isArray(v)&&v.length===3&&v.every(Number.isFinite);}

/** Interactive, camera-synchronizable geocentric scene. No external assets/network. */
export class SpaceView {
  constructor(canvas,{kind='real'}={}) {
    this.canvas=canvas;this.kind=kind;this.destroyed=false;this.onCameraChange=null;this.options={};
    this.renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:false,preserveDrawingBuffer:true});
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2));
    this.renderer.setClearColor(0x050c19);this.renderer.outputColorSpace=THREE.SRGBColorSpace;
    this.renderer.toneMapping=THREE.ACESFilmicToneMapping;this.renderer.toneMappingExposure=1.28;
    this.scene=new THREE.Scene();this.camera=new THREE.PerspectiveCamera(42,1,.05,240);this.camera.layers.enable(1);
    this.camera.position.set(17,14,20);this.camera.up.set(0,1,0);
    this.controls=new OrbitControls(this.camera,canvas);this.controls.enableDamping=false;
    this.controls.enablePan=true;this.controls.minDistance=3;this.controls.maxDistance=75;this.controls.target.set(0,0,0);
    this.controls.addEventListener('change',()=>{this.render();if(!this.syncing)this.onCameraChange?.(this);});
    this._makeStars();this._makePlanes();this._makeBodies();this._makeReferences();
    this.resizeObserver=new ResizeObserver(()=>{this.resize();this.render();});this.resizeObserver.observe(canvas);
    this.resize();this.controls.update();
  }
  _makeStars(){
    const pts=[];let seed=231;
    for(let i=0;i<550;i++){seed=(seed*16807)%2147483647;const a=seed/2147483647*Math.PI*2;seed=(seed*16807)%2147483647;const z=seed/2147483647*2-1;const q=Math.sqrt(1-z*z);pts.push(Math.cos(a)*q*85,z*85,Math.sin(a)*q*85);}
    const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(pts,3));
    this.stars=new THREE.Points(geo,new THREE.PointsMaterial({color:0xa3b9d7,size:.085,transparent:true,opacity:.7}));this.scene.add(this.stars);
  }
  _makePlanes(){
    this.grid=new THREE.Group();
    const vertices=[];
    for(let x=-12;x<=12;x+=2){vertices.push(x,0,-12,x,0,12,-12,0,x,12,0,x);}
    const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));
    this.grid.add(new THREE.LineSegments(geometry,new THREE.LineBasicMaterial({color:C.ecliptic,transparent:true,opacity:.25})));
    const disc=new THREE.Mesh(new THREE.CircleGeometry(12.8,80),new THREE.MeshBasicMaterial({color:0x315878,transparent:true,opacity:.045,side:THREE.DoubleSide,depthWrite:false}));disc.rotation.x=-Math.PI/2;this.grid.add(disc);
    const eclipLabel=label('黃道面', '#8ebcdf',2.2);eclipLabel.position.set(10,-.1,10);this.grid.add(eclipLabel);this.scene.add(this.grid);
    this.equator=new THREE.Group();
    const eqcircle=[];for(let j=0;j<=120;j++){const a=j/120*Math.PI*2;eqcircle.push(new THREE.Vector3(Math.cos(a)*5.5,0,-Math.sin(a)*5.5));}
    this.equator.add(line(eqcircle,C.equator,.45,true));
    const eqDisc=new THREE.Mesh(new THREE.CircleGeometry(5.5,64),new THREE.MeshBasicMaterial({color:C.equator,transparent:true,opacity:.055,side:THREE.DoubleSide,depthWrite:false}));eqDisc.rotation.x=-Math.PI/2;this.equator.add(eqDisc);
    const e=label('地球赤道面', '#f8b96b',2.7);e.position.set(-4.5,0,-2);this.equator.add(e);this.scene.add(this.equator);
    this.northArrow=new THREE.ArrowHelper(new THREE.Vector3(0,1,0),new THREE.Vector3(-11,0,-9),4,0x7cabc7,.55,.25);this.scene.add(this.northArrow);
    const north=label('黃道北極 +z', '#9dcde6',2.9);north.position.set(-11,4.7,-9);this.grid.add(north);
  }
  _makeBodies(){
    this.earthAxis=new THREE.Group();this.scene.add(this.earthAxis);
    this.earth=new THREE.Mesh(new THREE.SphereGeometry(1,64,48),new THREE.MeshLambertMaterial({map:earthTexture()}));this.earthAxis.add(this.earth);
    this.moon=new THREE.Mesh(new THREE.SphereGeometry(.34,56,40),new THREE.MeshLambertMaterial({map:moonTexture()}));this.moon.layers.set(1);this.scene.add(this.moon);
    this.overlayMoon=new THREE.Mesh(new THREE.SphereGeometry(.21,32,24),new THREE.MeshBasicMaterial({color:C.ideal,wireframe:true,transparent:true,opacity:.9}));this.scene.add(this.overlayMoon);this.overlayMoon.visible=false;
    const ambient=new THREE.AmbientLight(0x9aacc4,.025);ambient.layers.enable(1);this.scene.add(ambient);
    this.earthLight=new THREE.DirectionalLight(0xfff6e5,2.6);this.scene.add(this.earthLight);this.scene.add(this.earthLight.target);
    this.moonLight=new THREE.DirectionalLight(0xfff6e5,2.6);this.moonLight.layers.set(1);this.scene.add(this.moonLight);this.scene.add(this.moonLight.target);
    this.earthLabel=label('地球', '#a3dbff',1.8);this.earthLabel.position.set(0,-1.9,0);this.scene.add(this.earthLabel);
    this.moonLabel=label('月球', '#dcebf6',2.5);this.scene.add(this.moonLabel);
    this.axisArrow=new THREE.ArrowHelper(new THREE.Vector3(0,1,0),new THREE.Vector3(0,-1.9,0),4.5,0xf7c079,.4,.15);this.earthAxis.add(this.axisArrow);
    const earthNorth=label('地軸 23.44°', '#f8c782',2.9);earthNorth.position.set(0,3.1,0);this.earthAxis.add(earthNorth);
    const spin=[];for(let j=0;j<=48;j++){const a=j/48*Math.PI*1.65;spin.push(new THREE.Vector3(Math.cos(a)*1.6,.25,-Math.sin(a)*1.6));}
    this.earthAxis.add(line(spin,0xf7c079,.85));
    const spinEnd=spin[spin.length-1],spinPrev=spin[spin.length-2];this.spinArrow=new THREE.ArrowHelper(spinEnd.clone().sub(spinPrev).normalize(),spinEnd,.35,0xf7c079,.28,.14);this.earthAxis.add(this.spinArrow);
    const spinLabel=label('自轉 ↺（北極俯視）', '#f8c782',3.1);spinLabel.position.set(0,.3,-2.2);this.earthAxis.add(spinLabel);
    this.sunArrow=new THREE.ArrowHelper(new THREE.Vector3(1,0,0),new THREE.Vector3(10,0,0),3.1,0xffd27a,.8,.3);this.scene.add(this.sunArrow);
    this.sunLabel=label('太陽方向（遠方）', '#ffcf75',3.8);this.scene.add(this.sunLabel);
  }
  _makeReferences(){
    this.trail=line([],this.kind==='ideal'?C.ideal:C.real,.95);this.scene.add(this.trail);
    this.meanPath=line([],C.mean,.72,true);this.scene.add(this.meanPath);
    this.overlayPath=line([],C.ideal,.65,true);this.scene.add(this.overlayPath);this.overlayPath.visible=false;
    this.meanGroup=new THREE.Group();this.scene.add(this.meanGroup);
    this.nodeLine=line([],C.mean,.65,true);this.meanGroup.add(this.nodeLine);
    this.referenceMarkers=[];
    for(const [name,color] of [['示意升交點',0xc69af9],['示意降交點',0xc69af9],['示意近地點',0xffb8c2],['示意遠地點',0xffb8c2]]){
      const marker=new THREE.Mesh(new THREE.SphereGeometry(.12,16,12),new THREE.MeshBasicMaterial({color}));
      const text=label(name,'#d8b7ff',2.6);this.meanGroup.add(marker,text);this.referenceMarkers.push({marker,text});
    }
    this.inclinationArc=line([],0xe1b2fa,.95);this.meanGroup.add(this.inclinationArc);
    this.inclinationLabel=label('i = 5.145°', '#e1b2fa',2.9);this.meanGroup.add(this.inclinationLabel);
    this.prograde=new THREE.ArrowHelper(new THREE.Vector3(0,0,-1),new THREE.Vector3(9,0,0),1.1,this.kind==='ideal'?C.ideal:C.real,.5,.23);this.scene.add(this.prograde);
    this.directionLabel=label('月球順行 ↺',this.kind==='ideal'?'#83edb0':'#8ae2f3',2.8);this.scene.add(this.directionLabel);
    this.meanNotice=label('紫色：平均元素示意，非瞬時攝動軌道', '#d6b4fb',7.7);this.meanNotice.userData.screenAnchor=[0,-.90];this.scene.add(this.meanNotice);
  }
  update(snapshot,options={}) {
    if(this.destroyed)return;
    this.snapshot=snapshot;this.options={...this.options,...options};const o=this.options;
    const amp=clamp(Number(o.amplify)||1,1,8);
    const source=finiteVector(o.position)?o.position:snapshot.moonEcl;
    const sun=finiteVector(snapshot.sunEcl)?snapshot.sunEcl:[1,0,0];
    if(!finiteVector(source))throw new Error('太空 3D 缺少有效的黃道座標月球位置');
    const pos=world(source,amp);this.moon.position.copy(pos);
    const teaching=o.scale!=='distance';const earthSize=teaching?1:(6371/384400*ORBIT);const moonScale=teaching?1:(1737.4/384400*ORBIT/.34);
    this.earth.scale.setScalar(earthSize);this.moon.scale.setScalar(moonScale);
    const eps=(Number(snapshot.obliquity)||23.4393)*D;this.earthAxis.rotation.x=-eps;this.equator.rotation.x=-eps;
    this.earth.rotation.y=(Number(snapshot.siderealDeg)||0)*D;
    // Lighting vectors do not receive the visual z-exaggeration.
    const sunDirection=world(sun).normalize();this.earthLight.position.copy(sunDirection).multiplyScalar(65);this.earthLight.target.position.set(0,0,0);
    const moonToSun=world([sun[0]-source[0],sun[1]-source[1],sun[2]-source[2]]).normalize();
    this.moonLight.position.copy(pos).addScaledVector(moonToSun,50);this.moonLight.target.position.copy(pos);
    this.moon.rotation.y=Math.atan2(-pos.z,pos.x)+Math.PI/2;
    this.sunArrow.position.copy(sunDirection).multiplyScalar(10.6);this.sunArrow.setDirection(sunDirection);
    this.sunLabel.position.copy(sunDirection).multiplyScalar(15.6);this.sunLabel.position.y+=.9;
    this.moonLabel.position.copy(pos).add(new THREE.Vector3(0,.95,0));
    this.earthLabel.position.set(0,-(teaching?1.85:.7),0);
    this.grid.visible=o.showGrid!==false;this.equator.visible=o.showGrid!==false;this.northArrow.visible=o.showGrid!==false;
    const trail=o.trajectory||[];
    if(this.lastTrail!==trail||this.lastAmp!==amp){replaceGeometry(this.trail,trail.filter(finiteVector).map(p=>world(p,amp)));this.lastTrail=trail;}
    this.trail.visible=o.showTrail!==false&&trail.length>1;
    const inclination=Number.isFinite(o.inclination)?o.inclination:(this.kind==='ideal'?0:5.145),node=Number.isFinite(o.nodeDeg)?o.nodeDeg:125.08,peri=Number.isFinite(o.periDeg)?o.periDeg:318.15;
    const eccentricity=Number.isFinite(o.eccentricity)?o.eccentricity:(this.kind==='ideal'?0:.0549);
    const key=[inclination,node,peri,eccentricity,amp].join(',');
    if(this.meanKey!==key||this.lastMean!==o.meanOrbit){
      const path=o.meanOrbit||Array.from({length:241},(_,j)=>orbital(j/240*Math.PI*2,eccentricity,inclination,node,peri));
      replaceGeometry(this.meanPath,path.filter(finiteVector).map(p=>world(p,amp)));
      const nodes=[orbital(-peri*D,eccentricity,inclination,node,peri),orbital(Math.PI-peri*D,eccentricity,inclination,node,peri),orbital(0,eccentricity,inclination,node,peri),orbital(Math.PI,eccentricity,inclination,node,peri)];
      nodes.forEach((p,j)=>{const q=world(p,amp);this.referenceMarkers[j].marker.position.copy(q);this.referenceMarkers[j].text.position.copy(q).add(new THREE.Vector3(0,j%2?-.8:.8,0));});
      const N=node*D;replaceGeometry(this.nodeLine,[new THREE.Vector3(-Math.cos(N)*12,0,Math.sin(N)*12),new THREE.Vector3(Math.cos(N)*12,0,-Math.sin(N)*12)]);
      const arc=[];for(let j=0;j<=24;j++){const a=j/24*inclination*D;arc.push(new THREE.Vector3(-Math.sin(N)*Math.cos(a)*4.4,Math.sin(a)*4.4*amp,-Math.cos(N)*Math.cos(a)*4.4));}
      replaceGeometry(this.inclinationArc,arc);this.inclinationArc.visible=inclination>0;
      this.meanGroup.remove(this.inclinationLabel);disposeObject(this.inclinationLabel);
      this.inclinationLabel=label(`i = ${inclination.toFixed(3)}°${amp>1?'｜高度視覺 ×'+amp:''}`, '#e1b2fa',amp>1?4.8:2.9);
      this.inclinationLabel.position.copy(arc[arc.length-1]).add(new THREE.Vector3(0,.9,0));this.meanGroup.add(this.inclinationLabel);this.inclinationLabel.visible=inclination>0;
      this.meanKey=key;this.lastMean=o.meanOrbit;
    }
    this.meanPath.visible=o.showMean!==false;this.meanGroup.visible=o.showMean!==false;this.meanNotice.visible=o.showMean!==false;
    const sandbox=o.model==='sandbox'||this.kind==='sandbox';
    setLabelText(this.meanNotice,sandbox?'紫色：假設性克卜勒軌道（可調參）':'紫色：平均元素示意，非瞬時攝動軌道','#d6b4fb');
    this.referenceMarkers.forEach(({text},j)=>setLabelText(text,(sandbox?'假設':'示意')+['升交點','降交點','近地點','遠地點'][j],'#d8b7ff'));
    this.nodeLine.visible=inclination>1e-7;
    this.referenceMarkers.forEach(({marker,text},j)=>{marker.visible=j<2?inclination>1e-7:eccentricity>1e-7;text.visible=marker.visible;});
    if(trail.length>2){const j=Math.floor(trail.length*.66),p=world(trail[j],amp),next=world(trail[Math.min(j+1,trail.length-1)],amp);const d=next.sub(p);if(d.lengthSq()>1e-12){this.prograde.position.copy(p);this.prograde.setDirection(d.normalize());this.directionLabel.position.copy(p).add(new THREE.Vector3(0,1.05,0));}}
    else {const lon=Math.atan2(source[1],source[0]);this.prograde.position.copy(pos);this.prograde.setDirection(new THREE.Vector3(-Math.sin(lon),0,-Math.cos(lon)));this.directionLabel.position.copy(pos).add(new THREE.Vector3(0,1.2,0));}
    if(finiteVector(o.overlayPosition)){
      this.overlayMoon.visible=true;this.overlayMoon.position.copy(world(o.overlayPosition,amp));
    }else this.overlayMoon.visible=false;
    if(o.overlayPath&&(this.lastOverlay!==o.overlayPath||this.lastAmp!==amp)){replaceGeometry(this.overlayPath,o.overlayPath.filter(finiteVector).map(p=>world(p,amp)));this.lastOverlay=o.overlayPath;}
    this.overlayPath.visible=!!o.overlayPath&&o.overlayPath.length>1;
    this.lastAmp=amp;
    if(o.showLabels===false){this.scene.traverse(x=>{if(x.isSprite)x.visible=false;});}
    else {this.scene.traverse(x=>{if(x.isSprite)x.visible=true;});this.inclinationLabel.visible=inclination>0;this.referenceMarkers.forEach(({marker,text})=>text.visible=marker.visible);this.meanNotice.visible=o.showMean!==false;}
    this.render();
  }
  setView(view='free') {
    this.syncing=true;this.controls.target.set(0,0,0);
    if(view==='top'){this.camera.up.set(0,0,-1);this.camera.position.set(0,35,.001);}
    else if(view==='side'){this.camera.up.set(0,1,0);this.camera.position.set(0,.001,35);}
    else {this.camera.up.set(0,1,0);this.camera.position.set(17,14,20);}
    this.controls.update();this.syncing=false;this.render();this.onCameraChange?.(this);
  }
  setCameraFrom(other) {
    if(!other||this===other)return;this.syncing=true;
    this.camera.position.copy(other.camera.position);this.camera.quaternion.copy(other.camera.quaternion);this.camera.up.copy(other.camera.up);
    this.controls.target.copy(other.controls.target);this.controls.update();this.syncing=false;this.render();
  }
  resize() {
    if(this.destroyed)return;const r=this.canvas.getBoundingClientRect();const w=Math.max(1,Math.round(r.width)),h=Math.max(1,Math.round(r.height));
    const v=this.renderer.getSize(new THREE.Vector2());if(v.x!==w||v.y!==h){this.renderer.setSize(w,h,false);this.camera.aspect=w/h;this.camera.updateProjectionMatrix();}
  }
  _layoutLabels(){
    const viewport=this.renderer.getSize(new THREE.Vector2()),w=viewport.x,h=viewport.y;
    if(w<2||h<2)return;
    this.camera.updateMatrixWorld();this.scene.updateMatrixWorld(true);
    const labels=[];
    this.scene.traverse(s=>{
      if(!s.isSprite)return;
      const height=s.userData.cssHeight||19.2,scale=2*height/(h*this.camera.projectionMatrix.elements[5]);
      s.scale.set(scale*(s.userData.aspect||1),scale,1);s.center.set(.5,.5);
      let visible=s.visible;for(let p=s.parent;p&&visible;p=p.parent)visible=p.visible;
      if(!visible)return;
      if(s.userData.screenAnchor){const [x,y]=s.userData.screenAnchor;s.position.copy(new THREE.Vector3(x,y,0).unproject(this.camera));s.updateMatrixWorld(true);}
      const p=s.getWorldPosition(new THREE.Vector3()).project(this.camera);
      if(p.z<-1||p.z>1)return;
      labels.push({s,x:(p.x+1)*w/2,y:(1-p.y)*h/2,width:height*(s.userData.aspect||1),height});
    });
    // Retain every scientific label while separating nearby captions in screen
    // space. The anchor remains tied to its 3D point, including during rotation.
    const important=s=>s.userData.screenAnchor?0:([this.sunLabel,this.moonLabel,this.earthLabel].includes(s)?1:2);
    labels.sort((a,b)=>important(a.s)-important(b.s));const occupied=[];
    for(const item of labels){
      const {s,width,height,x,y}=item;let chosen=null,best=Infinity;
      const candidateOffsets=s.userData.screenAnchor?[0]:[0,-23,23,-46,46,-69,69];
      for(const dy of candidateOffsets){
        const cx=clamp(x,width/2+5,Math.max(width/2+5,w-width/2-5));
        const cy=clamp(y+dy,height/2+5,h-height/2-5);
        const box={left:cx-width/2-2,right:cx+width/2+2,top:cy-height/2-2,bottom:cy+height/2+2};
        let overlap=0;for(const b of occupied)overlap+=Math.max(0,Math.min(box.right,b.right)-Math.max(box.left,b.left))*Math.max(0,Math.min(box.bottom,b.bottom)-Math.max(box.top,b.top));
        const score=overlap+Math.abs(dy)*.01;
        if(score<best){best=score;chosen={box,cx,cy};}if(!overlap)break;
      }
      s.center.set(.5-(chosen.cx-x)/width,.5+(chosen.cy-y)/height);occupied.push(chosen.box);
    }
  }
  render(){if(this.destroyed)return;this.resize();this._layoutLabels();this.renderer.render(this.scene,this.camera);}
  dispose(){this.destroyed=true;this.resizeObserver.disconnect();this.controls.dispose();disposeObject(this.scene);this.renderer.dispose();}
}
function disposeObject(root){root.traverse(object=>{object.geometry?.dispose();const mats=Array.isArray(object.material)?object.material:[object.material];for(const mat of mats){if(mat){mat.map?.dispose();mat.dispose();}}});}
